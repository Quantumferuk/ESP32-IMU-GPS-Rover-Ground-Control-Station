"""Reusable Tkinter widgets for the rover GCS."""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Callable, Any

from .theme import THEME as C, FONT_MONO, FONT_MONO_BOLD, FONT_SMALL, FONT_TITLE


class DraggableNotebook(ttk.Notebook):
    """A ttk.Notebook whose tabs can be reordered by dragging.

    Usage: replace a Frame-based page host with this widget and add tab frames.
    """
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self._drag_start_index: Optional[int] = None
        self._rc_index: Optional[int] = None
        self.bind("<ButtonPress-1>", self._on_button_press, add="+")
        self.bind("<B1-Motion>", self._on_mouse_move, add="+")
        self.bind("<ButtonRelease-1>", self._on_button_release, add="+")
        self.bind("<Button-3>", self._on_right_click, add="+")
        self._menu = tk.Menu(self, tearoff=0)
        self._menu.add_command(label="Close Tab", command=self._close_tab)

    def _tab_index_at(self, x, y) -> Optional[int]:
        try:
            return self.index("@%d,%d" % (x, y))
        except Exception:
            return None

    def _on_button_press(self, event) -> None:
        self._drag_start_index = self._tab_index_at(event.x, event.y)

    def _on_mouse_move(self, event) -> None:
        if self._drag_start_index is None:
            return
        try:
            self.configure(cursor="fleur")
        except Exception:
            pass
        try:
            dst = self._tab_index_at(event.x, event.y)
            if dst is None or dst == self._drag_start_index:
                return
            # move the widget at drag_start_index to dst
            src_tab = self.tabs()[self._drag_start_index]
            try:
                src_widget = self.nametowidget(src_tab)
                self.insert(dst, src_widget)
                self._drag_start_index = dst
                self.select(dst)
            except Exception:
                pass
        except Exception:
            pass

    def _on_button_release(self, _event) -> None:
        self._drag_start_index = None
        try:
            self.configure(cursor="")
        except Exception:
            pass

    def _on_right_click(self, event) -> None:
        idx = self._tab_index_at(event.x, event.y)
        if idx is None:
            return
        self._rc_index = idx
        try:
            self._menu.tk_popup(event.x_root, event.y_root)
        finally:
            try:
                self._menu.grab_release()
            except Exception:
                pass

    def _close_tab(self) -> None:
        idx = getattr(self, "_rc_index", None)
        if idx is None:
            try:
                idx = self.index("current")
            except Exception:
                return
        try:
            self.forget(idx)
        except Exception:
            pass


class Card(tk.Frame):
    def __init__(
        self,
        parent,
        title: str = "",
        subtitle: str = "",
        detachable: bool = False,
        rebuild_callback: Optional[Callable[[tk.Frame], Any]] = None,
        swap_attrs: Optional[Sequence[str]] = None,
        build_func: Optional[Callable[[tk.Frame], Any]] = None,
        build_args: tuple = (),
        build_kwargs: Optional[dict] = None,
        **kwargs,
    ):
        super().__init__(parent, bg=C["line_soft"], padx=1, pady=1, **kwargs)
        self.build_func = build_func
        self.build_args = build_args or ()
        self.build_kwargs = build_kwargs or {}
        self._detachable = detachable
        self._rebuild = rebuild_callback
        self._swap_attrs = list(swap_attrs) if swap_attrs else []
        self._floating_win: Optional[tk.Toplevel] = None
        self._saved_attrs: Dict[str, object] = {}
        self._grid_info: Optional[Dict[str, object]] = None
        self._on_move_callback: Optional[Callable[[str], None]] = None
        self._on_detach_callback: Optional[Callable[[], None]] = None
        self._title = title

        outer = tk.Frame(self, bg=C["panel"], padx=14, pady=12)
        outer.pack(fill="both", expand=True)
        if title:
            header = tk.Frame(outer, bg=C["panel"])
            header.pack(fill="x", pady=(0, 10))
            tk.Label(header, text=title, bg=C["panel"], fg=C["text"], font=FONT_TITLE).pack(side="left")
            if subtitle:
                tk.Label(header, text=subtitle, bg=C["panel"], fg=C["muted"], font=FONT_SMALL).pack(side="left", padx=(10, 0))
            right_controls = tk.Frame(header, bg=C["panel"])
            right_controls.pack(side="right")
            self._move_btn = tk.Button(right_controls, text="↕", bg=C["panel"], fg=C["muted"], relief="flat", bd=0, command=self._on_move_click)
            self._move_btn.pack(side="right", padx=(6, 0))
            if self._detachable and self._rebuild:
                self._detach_btn = tk.Button(right_controls, text="↗", bg=C["panel"], fg=C["muted"], relief="flat", bd=0, command=self.toggle_detach)
                self._detach_btn.pack(side="right", padx=(6, 0))
            else:
                self._detach_btn = None
            tk.Label(right_controls, text="···", bg=C["panel"], fg=C["muted"], font=("Segoe UI", 12, "bold")).pack(side="right", padx=(8, 0))

        # resizers: vertical (bottom) and horizontal (right)
        self._v_resizer = tk.Frame(outer, bg=C["line_soft"], height=8, cursor="sb_v_double_arrow")
        self._v_resizer.pack(side="bottom", fill="x")
        self._v_resizer.bind("<ButtonPress-1>", self._start_v_resize)
        self._v_resizer.bind("<B1-Motion>", self._do_v_resize)

        self._h_resizer = tk.Frame(outer, bg=C["line_soft"], width=8, cursor="sb_h_double_arrow")
        self._h_resizer.pack(side="right", fill="y")
        self._h_resizer.bind("<ButtonPress-1>", self._start_h_resize)
        self._h_resizer.bind("<B1-Motion>", self._do_h_resize)

        self.body = tk.Frame(outer, bg=C["panel"])
        self.body.pack(fill="both", expand=True)

    def _start_v_resize(self, event):
        try:
            self._v_start_y = event.y_root
            self._v_start_h = self.winfo_height()
            gi = getattr(self, "_grid_info", None)
            if gi and isinstance(gi, dict) and gi.get("kwargs") and "row" in gi.get("kwargs"):
                self._v_row = gi["kwargs"]["row"]
                self._v_parent = self.master
            else:
                self._v_row = None
                self._v_parent = None
        except Exception:
            self._v_row = None
            self._v_parent = None

    def _do_v_resize(self, event):
        if getattr(self, "_v_row", None) is None:
            return
        try:
            dy = int(event.y_root - self._v_start_y)
            newh = max(40, int(self._v_start_h + dy))
            if getattr(self, "_v_parent", None) is not None:
                try:
                    self._v_parent.grid_rowconfigure(self._v_row, minsize=newh)
                except Exception:
                    pass
        except Exception:
            pass

    def _start_h_resize(self, event):
        try:
            self._h_start_x = event.x_root
            self._h_start_w = self.winfo_width()
            gi = getattr(self, "_grid_info", None)
            if gi and isinstance(gi, dict) and gi.get("kwargs") and "column" in gi.get("kwargs"):
                self._h_col = gi["kwargs"]["column"]
                self._h_parent = self.master
            else:
                self._h_col = None
                self._h_parent = None
        except Exception:
            self._h_col = None
            self._h_parent = None

    def _do_h_resize(self, event):
        if getattr(self, "_h_col", None) is None:
            return
        try:
            dx = int(event.x_root - self._h_start_x)
            neww = max(80, int(self._h_start_w + dx))
            if getattr(self, "_h_parent", None) is not None:
                try:
                    self._h_parent.grid_columnconfigure(self._h_col, minsize=neww)
                except Exception:
                    pass
        except Exception:
            pass

    def _on_move_click(self):
        if not self._on_move_callback:
            return
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Move Left", command=lambda: self._on_move_callback("left"))
        menu.add_command(label="Move Right", command=lambda: self._on_move_callback("right"))
        menu.add_command(label="Move Up", command=lambda: self._on_move_callback("up"))
        menu.add_command(label="Move Down", command=lambda: self._on_move_callback("down"))
        try:
            menu.tk_popup(self.winfo_rootx() + 10, self.winfo_rooty() + 24)
        finally:
            try:
                menu.grab_release()
            except Exception:
                pass

    def _on_detach_click(self):
        if self._on_detach_callback:
            self._on_detach_callback()

    def set_move_callback(self, cb: Callable[[str], None]) -> None:
        self._on_move_callback = cb

    def set_detach_callback(self, cb: Callable[[], None]) -> None:
        self._on_detach_callback = cb

    def run_build(self) -> None:
        for child in self.body.winfo_children():
            try:
                child.destroy()
            except Exception:
                pass
        if self.build_func:
            try:
                self.build_func(self.body, *self.build_args, **(self.build_kwargs or {}))
            except Exception:
                pass

    def grid(self, *args, **kwargs):
        super().grid(*args, **kwargs)
        try:
            self._grid_info = {"args": args, "kwargs": kwargs}
        except Exception:
            self._grid_info = None

    def toggle_detach(self):
        if self._floating_win:
            self._dock()
        else:
            self._detach()

    def _detach(self):
        if not self._rebuild:
            return
        app = self.winfo_toplevel()
        # save attributes from app that will be overwritten by rebuild
        self._saved_attrs = {}
        for name in self._swap_attrs:
            try:
                self._saved_attrs[name] = getattr(app, name)
            except Exception:
                self._saved_attrs[name] = None
        # record original parent so we can re-add later (supports PanedWindow)
        try:
            self._orig_parent = self.master
        except Exception:
            self._orig_parent = None
        # try to remove from parent (works for grid/pack and PanedWindow)
        try:
            if hasattr(self._orig_parent, "forget"):
                try:
                    self._orig_parent.forget(self)
                except Exception:
                    pass
            try:
                self.grid_remove()
            except Exception:
                try:
                    self.pack_forget()
                except Exception:
                    try:
                        self.place_forget()
                    except Exception:
                        pass
        except Exception:
            pass
        # create floating window
        top = tk.Toplevel(app)
        top.title(self._title or "Panel")
        top.configure(bg=C["bg"]) 
        # header inside floating window with dock button
        header_top = tk.Frame(top, bg=C["panel"], padx=8, pady=6)
        header_top.pack(fill="x")
        tk.Label(header_top, text=self._title or "", bg=C["panel"], fg=C["text"], font=FONT_TITLE).pack(side="left")
        dock_btn = tk.Button(header_top, text="↙", bg=C["panel"], fg=C["muted"], relief="flat", bd=0, command=self._dock)
        dock_btn.pack(side="right")
        body = tk.Frame(top, bg=C["panel"], padx=8, pady=8)
        body.pack(fill="both", expand=True)
        try:
            self._rebuild(body)
        except Exception:
            pass
        self._floating_win = top

    def _dock(self):
        if not self._floating_win:
            return
        try:
            self._floating_win.destroy()
        except Exception:
            pass
        self._floating_win = None
        app = self.winfo_toplevel()
        for name, val in self._saved_attrs.items():
            try:
                setattr(app, name, val)
            except Exception:
                pass
        try:
            if hasattr(self, "_grid_info") and self._grid_info:
                self.grid(*self._grid_info.get("args", ()), **self._grid_info.get("kwargs", {}))
            else:
                self.pack(fill="both", expand=True)
        except Exception:
            pass
        if self._detach_btn:
            try:
                self._detach_btn.configure(text="↗")
            except Exception:
                pass


class StatusTile(tk.Frame):
    def __init__(self, parent, title: str, value: str, width: int = 155):
        super().__init__(parent, bg=C["line_soft"], padx=1, pady=1, width=width, height=56)
        self.pack_propagate(False)
        body = tk.Frame(self, bg=C["panel"], padx=12, pady=8)
        body.pack(fill="both", expand=True)
        tk.Label(body, text=title, bg=C["panel"], fg=C["muted"], font=("Consolas", 8, "bold")).pack(anchor="w")
        self.var = tk.StringVar(value=value)
        self.label = tk.Label(body, textvariable=self.var, bg=C["panel"], fg=C["text"], font=FONT_MONO_BOLD)
        self.label.pack(anchor="w")

    def set(self, value: str, color: Optional[str] = None) -> None:
        self.var.set(value)
        if color:
            self.label.configure(fg=color)


class TelemetryRow(tk.Frame):
    def __init__(self, parent, name: str, value: str = "--", unit: str = ""):
        super().__init__(parent, bg=C["panel"], height=27)
        self.pack_propagate(False)
        self.pack(fill="x", pady=1)
        tk.Label(self, text=name, bg=C["panel"], fg=C["muted"], font=FONT_MONO).pack(side="left")
        right = tk.Frame(self, bg=C["panel"])
        right.pack(side="right")
        self.var = tk.StringVar(value=value)
        self.value_label = tk.Label(right, textvariable=self.var, bg=C["panel"], fg=C["text_soft"], font=FONT_MONO_BOLD)
        self.value_label.pack(side="left")
        if unit:
            tk.Label(right, text=f" {unit}", bg=C["panel"], fg=C["muted"], font=FONT_MONO).pack(side="left")

    def set(self, value: str, color: Optional[str] = None) -> None:
        self.var.set(value)
        if color:
            self.value_label.configure(fg=color)
        else:
            self.value_label.configure(fg=C["text_soft"])


class MetricBox(tk.Frame):
    def __init__(self, parent, title: str, value: str = "--", color: Optional[str] = None):
        super().__init__(parent, bg=C["panel2"], padx=12, pady=10, height=76)
        self.pack_propagate(False)
        self.grid_propagate(False)
        tk.Label(self, text=title, bg=C["panel2"], fg=C["muted"], font=("Consolas", 9, "bold")).pack(anchor="w")
        self.var = tk.StringVar(value=value)
        self.value = tk.Label(self, textvariable=self.var, bg=C["panel2"], fg=color or C["text"], font=("Segoe UI", 13, "bold"))
        self.value.pack(anchor="w", pady=(2, 0))

    def set(self, value: str, color: Optional[str] = None) -> None:
        self.var.set(value)
        self.value.configure(fg=color or C["text"])


class CanvasGraph(tk.Canvas):
    def __init__(self, parent, title: str, height: int = 130, y_label: str = ""):
        super().__init__(parent, height=height, bg=C["graph_bg"], highlightthickness=1, highlightbackground=C["line_soft"])
        self.title = title
        self.y_label = y_label
        self.series: Dict[str, Sequence[float]] = {}
        self.x: Sequence[float] = []
        self.fixed_ylim: Optional[Tuple[float, float]] = None
        self.colors = [C["plot1"], C["plot2"], C["plot3"], C["plot4"], C["plot5"]]
        self.bind("<Configure>", lambda _e: self.draw())

    def update_series(self, x: Sequence[float], series: Dict[str, Sequence[float]], fixed_ylim: Optional[Tuple[float, float]] = None) -> None:
        self.x = list(x)
        self.series = {k: list(v) for k, v in series.items()}
        self.fixed_ylim = fixed_ylim
        self.draw()

    def draw(self) -> None:
        self.delete("all")
        w = max(100, self.winfo_width())
        h = max(80, self.winfo_height())
        ml, mr, mt, mb = 40, 12, 24, 24
        x0, y0, x1, y1 = ml, mt, w - mr, h - mb
        self.create_text(10, 8, text=self.title, fill=C["text"], font=("Consolas", 9, "bold"), anchor="nw")
        self.create_rectangle(x0, y0, x1, y1, outline=C["line"], fill=C["graph_bg"])
        for i in range(1, 4):
            y = y0 + (y1 - y0) * i / 4
            self.create_line(x0, y, x1, y, fill=C["graph_grid"], dash=(3, 5))
        for i in range(1, 5):
            x = x0 + (x1 - x0) * i / 5
            self.create_line(x, y0, x, y1, fill=C["graph_grid"], dash=(3, 5))

        if len(self.x) < 2 or not any(len(v) >= 2 for v in self.series.values()):
            self.create_text((x0 + x1) / 2, (y0 + y1) / 2, text="REAL TELEMETRY WAITING", fill=C["muted"], font=FONT_MONO_BOLD)
            return

        xmin = max(0.0, self.x[-1] - 120.0)
        xmax = max(30.0, self.x[-1])
        values: List[float] = []
        for vals in self.series.values():
            values.extend([float(v) for v in vals[-len(self.x):]])
        if self.fixed_ylim:
            ymin, ymax = self.fixed_ylim
        else:
            ymin = min(values) if values else -1.0
            ymax = max(values) if values else 1.0
            if abs(ymax - ymin) < 1e-6:
                ymin -= 1.0
                ymax += 1.0
            pad = 0.12 * (ymax - ymin)
            ymin -= pad
            ymax += pad

        def map_xy(tx: float, vy: float) -> Tuple[float, float]:
            px = x0 + (tx - xmin) / max(1e-9, xmax - xmin) * (x1 - x0)
            py = y1 - (vy - ymin) / max(1e-9, ymax - ymin) * (y1 - y0)
            return px, py

        for idx, (name, vals) in enumerate(self.series.items()):
            pts: List[float] = []
            offset = len(self.x) - len(vals)
            for i, val in enumerate(vals):
                xi = i + max(0, offset)
                if xi >= len(self.x):
                    continue
                tx = float(self.x[xi])
                if tx < xmin:
                    continue
                px, py = map_xy(tx, float(val))
                pts.extend([px, py])
            if len(pts) >= 4:
                self.create_line(*pts, fill=self.colors[idx % len(self.colors)], width=1.6, smooth=False)
            self.create_text(x1 - 76 + (idx % 3) * 40, 10 + (idx // 3) * 13, text=name, fill=self.colors[idx % len(self.colors)], font=("Consolas", 8), anchor="nw")

        self.create_text(x0, y1 + 12, text=f"-{int(xmax - xmin)}s", fill=C["muted"], font=("Consolas", 8), anchor="w")
        self.create_text(x1, y1 + 12, text="0s", fill=C["muted"], font=("Consolas", 8), anchor="e")
        self.create_text(4, y0, text=f"{ymax:.1f}", fill=C["muted"], font=("Consolas", 8), anchor="nw")
        self.create_text(4, y1 - 10, text=f"{ymin:.1f}", fill=C["muted"], font=("Consolas", 8), anchor="sw")


class ScrollableFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=C["bg"])
        self.canvas = tk.Canvas(self, bg=C["bg"], highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.content = tk.Frame(self.canvas, bg=C["bg"])
        self.window_id = self.canvas.create_window((0, 0), window=self.content, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.content.bind("<Configure>", self._on_content_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _on_content_configure(self, _event) -> None:
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event) -> None:
        self.canvas.itemconfigure(self.window_id, width=event.width)

    def _on_mousewheel(self, event) -> None:
        try:
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass

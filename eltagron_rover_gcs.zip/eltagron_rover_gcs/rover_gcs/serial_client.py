"""Serial communication backend.

Protocol preserved from the first working UI:
- TX commands: F, B, L, R, S, 1, 2, 3
- RX frames: GPS:lat,lon,speed_kmph and IMU:yaw,ax,ay,az
"""
from __future__ import annotations
import queue
import threading
import time
from typing import List, Optional

try:
    import serial
    import serial.tools.list_ports
except Exception:  # pragma: no cover - optional runtime dependency
    serial = None


class SerialClient:
    def __init__(self, baud_rate: int = 115200, timeout: float = 0.05) -> None:
        self.baud_rate = baud_rate
        self.timeout = timeout
        self.ser: Optional[object] = None
        self.rx_queue: queue.Queue[str] = queue.Queue()
        self._alive = False
        self._thread: Optional[threading.Thread] = None

    @property
    def available(self) -> bool:
        return serial is not None

    @property
    def connected(self) -> bool:
        return bool(self.ser and getattr(self.ser, "is_open", False))

    def ports(self) -> List[str]:
        if serial is None:
            return []
        return [p.device for p in serial.tools.list_ports.comports()]

    def connect(self, port: str) -> None:
        if serial is None:
            raise RuntimeError("pyserial kurulu değil. Kurulum: pip install pyserial")
        self.ser = serial.Serial(port, self.baud_rate, timeout=self.timeout)
        time.sleep(1.6)  # ESP32/USB serial reset sonrası kartın ayağa kalkması için
        self._alive = True
        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()

    def disconnect(self) -> None:
        self._alive = False
        try:
            if self.ser and getattr(self.ser, "is_open", False):
                self.ser.close()
        finally:
            self.ser = None

    def send(self, cmd: str) -> bool:
        if not self.connected:
            return False
        self.ser.write(cmd.encode("ascii"))
        return True

    def _worker(self) -> None:
        while self._alive:
            try:
                if self.connected:
                    line = self.ser.readline().decode("utf-8", errors="ignore").strip()
                    if line:
                        self.rx_queue.put(line)
                else:
                    time.sleep(0.1)
            except Exception as exc:
                self.rx_queue.put(f"ERR:{exc}")
                time.sleep(0.2)

"""Eltagron Rover GCS v6 package."""

"""Data models used by the rover ground control station."""
from dataclasses import dataclass, field
from collections import deque
from typing import Deque, Optional

@dataclass
class Telemetry:
    lat: float = 0.0
    lon: float = 0.0
    speed_kmph: float = 0.0
    yaw_deg: float = 0.0
    ax_g: float = 0.0
    ay_g: float = 0.0
    az_g: float = 0.0
    distance_m: float = 0.0
    packets: int = 0
    last_rx_ms: int = 0
    last_gps_ms: int = 0
    last_imu_ms: int = 0
    last_line: str = ""
    gps_fix: bool = False

@dataclass
class History:
    maxlen: int = 900
    t: Deque[float] = field(default_factory=lambda: deque(maxlen=900))
    yaw: Deque[float] = field(default_factory=lambda: deque(maxlen=900))
    speed: Deque[float] = field(default_factory=lambda: deque(maxlen=900))
    ax: Deque[float] = field(default_factory=lambda: deque(maxlen=900))
    ay: Deque[float] = field(default_factory=lambda: deque(maxlen=900))
    az: Deque[float] = field(default_factory=lambda: deque(maxlen=900))

    def append(self, timestamp_s: float, tel: Telemetry) -> None:
        self.t.append(timestamp_s)
        self.yaw.append(tel.yaw_deg)
        self.speed.append(tel.speed_kmph)
        self.ax.append(tel.ax_g)
        self.ay.append(tel.ay_g)
        self.az.append(tel.az_g)

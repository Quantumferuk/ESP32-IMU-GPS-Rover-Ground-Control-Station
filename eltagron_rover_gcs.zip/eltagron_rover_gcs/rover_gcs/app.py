"""Main Tkinter application for Eltagron Rover GCS v6.

This version intentionally preserves the first working serial/control backend:
- same COM-port workflow
- same command bytes: F/B/L/R/S/1/2/3
- same telemetry parser: GPS:lat,lon,speed_kmph and IMU:yaw,ax,ay,az
- no simulated GPS/IMU data is generated
"""
from __future__ import annotations

import math
import time
import tkinter as tk
from tkinter import messagebox, ttk, simpledialog
from typing import Dict, List, Optional, Sequence

try:
    import tkintermapview
except Exception:  # pragma: no cover
    tkintermapview = None

from .filters import kalman_1d, low_pass, moving_average
from .models import History, Telemetry
from .serial_client import SerialClient
from .theme import THEME as C, FONT_BODY, FONT_MONO, FONT_MONO_BOLD, FONT_SMALL, FONT_TITLE
from .widgets import CanvasGraph, Card, MetricBox, ScrollableFrame, StatusTile, TelemetryRow, DraggableNotebook

BAUD_RATE = 115200
COMMAND_DEADMAN_MS = 600
UI_REFRESH_MS = 80
TELEMETRY_STALE_MS = 1200
MAX_LOG_LINES = 250

COMMANDS = {
    "F": "FORWARD",
    "B": "BACK",
    "L": "LEFT",
    "R": "RIGHT",
    "S": "STOP",
    "1": "SPEED LOW",
    "2": "SPEED MID",
    "3": "SPEED HIGH",
}

PAGES = [
    ("⌂", "Dashboard"),
    ("↯", "Telemetry"),
    ("▥", "Analysis"),
    ("≋", "Filter Lab"),
    ("⚒", "Troubleshooter"),
    ("▤", "Logs"),
    ("⚙", "Settings"),
]


class RoverGCSApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("ELTAGRON ROVER GCS v6.1 | Visual Refined")
        self.geometry("1660x940")
        self.minsize(1260, 760)
        self.configure(bg=C["bg"])

        self.serial = SerialClient(baud_rate=BAUD_RATE)
        self.telemetry = Telemetry()
        self.history = History()
        self.t0 = time.time()
        self.last_cmd = "S"
        self.last_motion_cmd_ms = self.now_ms()
        self.pressed_keys = set()
        self.prev_lat = 0.0
        self.prev_lon = 0.0
        self.path_points: List[tuple[float, float]] = []
        self.map_marker = None
        self.map_path = None
        self.sidebar_expanded = True
        self.current_page = "Dashboard"
        self.page_frames: Dict[str, tk.Frame] = {}
        self.mode = "MANUAL"
        self.filter_mode = tk.StringVar(value="RAW")
        self.event_lines: List[str] = []
        self.lowpass_alpha = tk.DoubleVar(value=0.15)
        self.ma_window = tk.IntVar(value=12)
        self.kalman_q = tk.DoubleVar(value=0.001)
        self.kalman_r = tk.DoubleVar(value=0.5)

        self.style = ttk.Style(self)
        self.setup_style()
        self.build_root_layout()
        self.bind_keys()
        self.refresh_ports()
        self.log_event("INFO", "GCS application started. Real telemetry waiting.")
        self.after(UI_REFRESH_MS, self.ui_loop)

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------
    def setup_style(self) -> None:
        self.style.theme_use("clam")
        self.style.configure("TCombobox", fieldbackground=C["panel2"], background=C["panel2"], foreground=C["text"], arrowcolor=C["text"], bordercolor=C["line"])
        self.style.configure("TButton", background=C["panel2"], foreground=C["text"], borderwidth=0, focusthickness=0, padding=7)
        self.style.map("TButton", background=[("active", C["accent"])])
        self.style.configure("Vertical.TScrollbar", background=C["panel2"], troughcolor=C["bg"], arrowcolor=C["text"], bordercolor=C["line"])

    def build_root_layout(self) -> None:
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=1)

        self.sidebar = tk.Frame(self, bg=C["panel"], width=145)
        self.sidebar.grid(row=0, column=0, rowspan=2, sticky="nsw")
        self.sidebar.grid_propagate(False)
        self.build_sidebar()

        self.topbar = tk.Frame(self, bg=C["bg"], padx=8, pady=7)
        self.topbar.grid(row=0, column=1, sticky="ew")
        self.topbar.grid_columnconfigure(7, weight=1)
        self.build_topbar()

        self.page_notebook = DraggableNotebook(self)
        self.page_notebook.grid(row=1, column=1, sticky="nsew", padx=8, pady=(0, 8))
        self.show_page("Dashboard")

    def build_sidebar(self) -> None:
        for child in self.sidebar.winfo_children():
            child.destroy()
        width = 145 if self.sidebar_expanded else 56
        self.sidebar.configure(width=width)
        btn = tk.Button(self.sidebar, text="☰", command=self.toggle_sidebar, bg=C["panel"], fg=C["text"], activebackground=C["panel2"], relief="flat", bd=0, font=("Segoe UI", 18), height=2)
        btn.pack(fill="x")
        for icon, name in PAGES:
            text = f"{icon}   {name}" if self.sidebar_expanded else icon
            b = tk.Button(self.sidebar, text=text, anchor="w" if self.sidebar_expanded else "center", command=lambda n=name: self.show_page(n), bg=C["panel2"] if name == self.current_page else C["panel"], fg=C["accent2"] if name == self.current_page else C["text_soft"], activebackground=C["panel2"], activeforeground=C["text"], relief="flat", bd=0, padx=14, pady=12, font=FONT_BODY)
            b.pack(fill="x", pady=1)
        tk.Frame(self.sidebar, bg=C["panel"]).pack(fill="both", expand=True)
        self.system_ok_label = tk.Label(self.sidebar, text="● SYSTEM OK" if self.sidebar_expanded else "●", bg=C["panel"], fg=C["ok"], font=FONT_MONO_BOLD)
        self.system_ok_label.pack(anchor="w" if self.sidebar_expanded else "center", padx=14, pady=(0, 18))

    def build_topbar(self) -> None:
        tk.Label(self.topbar, text="ESP32 ROVER GCS", bg=C["bg"], fg=C["text"], font=("Segoe UI", 14, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 12))
        tk.Label(self.topbar, text="IMU-GPS TEST PLATFORM", bg=C["bg"], fg=C["muted"], font=("Consolas", 9)).grid(row=1, column=0, sticky="w")

        self.tile_connection = StatusTile(self.topbar, "CONNECTION", "● DISCONNECTED", 160)
        self.tile_connection.grid(row=0, column=1, rowspan=2, padx=5, sticky="ns")
        self.tile_mode = StatusTile(self.topbar, "MODE", "◇ MANUAL", 150)
        self.tile_mode.grid(row=0, column=2, rowspan=2, padx=5, sticky="ns")
        self.tile_gps = StatusTile(self.topbar, "GPS FIX", "NO FIX", 150)
        self.tile_gps.grid(row=0, column=3, rowspan=2, padx=5, sticky="ns")
        self.tile_log = StatusTile(self.topbar, "LOGGING", "OFF", 150)
        self.tile_log.grid(row=0, column=4, rowspan=2, padx=5, sticky="ns")
        self.tile_cmd = StatusTile(self.topbar, "ACTIVE COMMAND", "STOP", 190)
        self.tile_cmd.grid(row=0, column=5, rowspan=2, padx=5, sticky="ns")
        self.tile_power = StatusTile(self.topbar, "POWER", "UNKNOWN", 150)
        self.tile_power.grid(row=0, column=6, rowspan=2, padx=5, sticky="ns")
        self.tile_time = StatusTile(self.topbar, "SYSTEM TIME (LOCAL)", "--:--:--", 190)
        self.tile_time.grid(row=0, column=8, rowspan=2, padx=5, sticky="e")
        self.tile_session = StatusTile(self.topbar, "SESSION TIME", "00:00:00", 145)
        self.tile_session.grid(row=0, column=9, rowspan=2, padx=(5, 0), sticky="e")

    def toggle_sidebar(self) -> None:
        self.sidebar_expanded = not self.sidebar_expanded
        self.build_sidebar()

    def show_page(self, page: str) -> None:
        self.current_page = page
        self.clear_page_refs()
        # Create tab content lazily and select the corresponding tab frame.
        if page not in self.page_frames:
            frame = tk.Frame(self.page_notebook, bg=C["bg"])
            self.page_frames[page] = frame
            self.page_notebook.add(frame, text=page)
            if page == "Dashboard":
                self.build_dashboard_page(frame)
            elif page == "Telemetry":
                self.build_telemetry_page(frame)
            elif page == "Analysis":
                self.build_analysis_page(frame)
            elif page == "Filter Lab":
                self.build_filter_page(frame)
            elif page == "Troubleshooter":
                self.build_troubleshooter_page(frame)
            elif page == "Logs":
                self.build_logs_page(frame)
            else:
                self.build_settings_page(frame)
        frame = self.page_frames[page]
        self.page_notebook.select(frame)
        self.build_sidebar()


    def clear_page_refs(self) -> None:
        """Clear references to widgets that are destroyed during page switches."""
        attrs = [
            "vehicle_state", "mission_state", "armed_state", "health_state", "distance_state", "packet_state",
            "row_lat", "row_lon", "row_speed", "row_yaw", "row_acc", "row_sat", "row_link", "row_packet", "row_age", "row_last",
            "graph_yaw", "graph_acc", "graph_speed", "graph_path", "graph_error", "graph_filter",
            "analysis_yaw", "analysis_acc", "analysis_speed", "analysis_filter", "filter_page_graph",
            "fallback_map", "fallback_map_note", "event_text", "diag_text", "map_widget", "map_marker", "map_path",
        ]
        for attr in attrs:
            if hasattr(self, attr):
                try:
                    delattr(self, attr)
                except Exception:
                    pass
        self.diag = {}

    def build_dashboard_page(self, parent) -> None:
        """Dashboard layout only. Backend/serial protocol is unchanged.

        Reference hedefi:
        - Sol harita alanı daha geniş tutulur.
        - Orta kolon vehicle status + command/control olarak kalır.
        - Sağ kolon telemetry olarak kalır.
        - Grafik/filter/troubleshooter/log alanları aynı veri kaynaklarını kullanır.
        """
        # Use the provided parent frame (notebook tab) as the root to avoid
        # nested packing issues that break grid geometry inside tabs.
        root = parent
        root.configure(bg=C["bg"])
        # Use PanedWindow for top row so user can resize left/mid/right panes
        root.grid_columnconfigure(0, weight=1)
        root.grid_columnconfigure(1, weight=1)
        root.grid_columnconfigure(2, weight=1)
        root.grid_rowconfigure(0, weight=7, minsize=360)
        root.grid_rowconfigure(1, weight=3, minsize=170)
        root.grid_rowconfigure(2, weight=3, minsize=160)

        # Use a vertical PanedWindow so the user can resize top/analysis/bottom heights
        self.main_pane = tk.PanedWindow(root, orient="vertical", sashrelief="raised", sashwidth=8, bg=C["line_soft"])
        self.main_pane.grid(row=0, column=0, columnspan=3, rowspan=3, sticky="nsew")

        top_area = tk.Frame(self.main_pane, bg=C["bg"]) 
        analysis_area = tk.Frame(self.main_pane, bg=C["bg"]) 
        bottom_area = tk.Frame(self.main_pane, bg=C["bg"]) 
        self.main_pane.add(top_area, minsize=360)
        self.main_pane.add(analysis_area, minsize=170)
        self.main_pane.add(bottom_area, minsize=160)

        # Top row: three horizontal panes (left map, middle status/control, right telemetry)
        self.top_pane = tk.PanedWindow(top_area, orient="horizontal", sashrelief="raised", sashwidth=8, bg=C["line_soft"])
        self.top_pane.pack(fill="both", expand=True, padx=(0, 5), pady=(0, 5))
        left_frame = tk.Frame(self.top_pane, bg=C["panel2"])
        mid_frame = tk.Frame(self.top_pane, bg=C["bg"])
        right_frame = tk.Frame(self.top_pane, bg=C["panel"])
        self.top_pane.add(left_frame, minsize=400)
        self.top_pane.add(mid_frame, minsize=320)
        self.top_pane.add(right_frame, minsize=260)

        map_card = Card(
            left_frame,
            "LIVE ROVER MAP",
            detachable=True,
            rebuild_callback=lambda p: self.build_map(p, height=420),
            swap_attrs=("map_widget", "map_marker", "map_path", "fallback_map", "fallback_map_note"),
        )
        map_card.pack(fill="both", expand=True, padx=(0, 5), pady=(0, 5))
        self.build_map(map_card.body, height=420)

        mid_frame.grid_columnconfigure(0, weight=1)
        mid_frame.grid_rowconfigure(0, weight=1)
        mid_frame.grid_rowconfigure(1, weight=1)
        self.build_vehicle_status(mid_frame).grid(row=0, column=0, sticky="nsew", pady=(0, 5))
        self.build_command_control(mid_frame).grid(row=1, column=0, sticky="nsew", pady=(5, 0))

        telemetry = self.build_telemetry_card(right_frame)
        telemetry.pack(fill="both", expand=True, padx=(5, 0), pady=(0, 5))

        # Analysis area (middle row)
        analysis = Card(
            analysis_area,
            "ANALYSIS",
            "real telemetry only",
            detachable=True,
            rebuild_callback=lambda p: self.build_dashboard_graphs(p),
            swap_attrs=("graph_yaw", "graph_acc", "graph_speed", "graph_path", "graph_error", "graph_filter"),
        )
        analysis.pack(fill="both", expand=True, pady=5, padx=5)
        self.build_dashboard_graphs(analysis.body)

        # Bottom row: three horizontal panes
        self.bottom_pane = tk.PanedWindow(bottom_area, orient="horizontal", sashrelief="raised", sashwidth=8, bg=C["line_soft"])
        self.bottom_pane.pack(fill="both", expand=True, pady=(5, 0))
        left_btm = tk.Frame(self.bottom_pane, bg=C["panel"]) 
        mid_btm = tk.Frame(self.bottom_pane, bg=C["panel"]) 
        right_btm = tk.Frame(self.bottom_pane, bg=C["panel"]) 
        self.bottom_pane.add(left_btm, minsize=300)
        self.bottom_pane.add(mid_btm, minsize=300)
        self.bottom_pane.add(right_btm, minsize=300)

        filter_card = self.build_filter_lab_card(left_btm)
        filter_card.pack(fill="both", expand=True, padx=(0, 5), pady=(5, 0))
        trouble_card = self.build_troubleshooter_card(mid_btm)
        trouble_card.pack(fill="both", expand=True, padx=5, pady=(5, 0))
        log_card = self.build_event_log_card(right_btm)
        log_card.pack(fill="both", expand=True, padx=(5, 0), pady=(5, 0))

        # Apply a reasonable default ratio layout shortly after construction
        try:
            default_ratio_layout = {
                "main_pane": [0.58, 0.28, 0.14],
                "top_pane": [0.62, 0.25, 0.13],
                "bottom_pane": [0.22, 0.28, 0.50],
            }
            self.after(120, lambda: self.restore_ratio_layout(default_ratio_layout, attempts=8, delay=0.05))
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Programmatic PanedWindow control helpers
    # ------------------------------------------------------------------
    def _set_sashpos(self, pane: Optional[tk.PanedWindow], index: int, pos: int) -> bool:
        """Try to set sash position for a PanedWindow instance robustly.

        Returns True on success, False otherwise.
        """
        if not pane or not isinstance(pane, tk.PanedWindow):
            return False
        try:
            # try direct sashpos setter (may raise TypeError on some builds)
            pane.sashpos(index, pos)
            return True
        except TypeError:
            try:
                orient = pane.cget("orient")
                w = pane.winfo_width() or self.winfo_width() or 200
                h = pane.winfo_height() or self.winfo_height() or 200
                if orient == "horizontal":
                    pane.sash_place(index, pos, h // 2)
                else:
                    pane.sash_place(index, w // 2, pos)
                return True
            except Exception:
                return False
        except Exception:
            try:
                # fallback to tk.call
                pane.tk.call(pane._w, "sashpos", index, pos)
                return True
            except Exception:
                return False

    def set_pane_sashpos(self, pane_attr: str, index: int, pos: int) -> bool:
        """Set sash position by pane attribute name (e.g. 'top_pane')."""
        pane = getattr(self, pane_attr, None)
        return self._set_sashpos(pane, index, pos)

    def set_top_sash(self, index: int, pos: int) -> bool:
        return self._set_sashpos(getattr(self, "top_pane", None), index, pos)

    def set_bottom_sash(self, index: int, pos: int) -> bool:
        return self._set_sashpos(getattr(self, "bottom_pane", None), index, pos)

    def set_main_sash(self, index: int, pos: int) -> bool:
        return self._set_sashpos(getattr(self, "main_pane", None), index, pos)

    def restore_layout(self, layout: Dict[str, Sequence[int]], attempts: int = 6, delay: float = 0.06) -> Dict[str, list]:
        """Aggressively restore sash positions from a layout dict.

        layout: mapping of pane attribute name -> list of sash positions (px)
        attempts: number of retry attempts with update_idletasks between tries
        delay: sleep between attempts

        Returns a dict of final sash positions for each pane.
        """
        results: Dict[str, list] = {}
        for name, poses in layout.items():
            results[name] = [None] * len(poses)

        for attempt in range(attempts):
            any_pending = False
            try:
                self.update_idletasks()
            except Exception:
                pass
            for name, poses in layout.items():
                pane = getattr(self, name, None)
                if not pane or not isinstance(pane, tk.PanedWindow):
                    continue
                for idx, pos in enumerate(poses):
                    try:
                        # primary: low-level tk call
                        try:
                            pane.tk.call(pane._w, "sashpos", idx, pos)
                        except Exception:
                            # try higher-level helpers
                            try:
                                pane.sashpos(idx, pos)
                            except Exception:
                                orient = pane.cget("orient")
                                w = pane.winfo_width() or self.winfo_width() or 200
                                h = pane.winfo_height() or self.winfo_height() or 200
                                if orient == "horizontal":
                                    try:
                                        pane.sash_place(idx, pos, h // 2)
                                    except Exception:
                                        pass
                                else:
                                    try:
                                        pane.sash_place(idx, w // 2, pos)
                                    except Exception:
                                        pass
                    except Exception:
                        pass
                    # read back position if possible
                    cur = None
                    try:
                        cur = pane.tk.call(pane._w, "sashpos", idx)
                        # tk returns string sometimes
                        try:
                            cur = int(cur)
                        except Exception:
                            pass
                    except Exception:
                        try:
                            cur = pane.sashpos(idx)
                        except Exception:
                            cur = None
                    results[name][idx] = cur
                    if cur is None or (isinstance(cur, int) and cur != poses[idx]):
                        any_pending = True
            try:
                self.update()
            except Exception:
                pass
            if not any_pending:
                break
            time.sleep(delay)
        return results

    def restore_ratio_layout(self, ratio_layout: Dict[str, Sequence[float]], attempts: int = 6, delay: float = 0.06) -> Dict[str, list]:
        """Restore sash positions using per-pane child ratios (fractions summing to 1).

        ratio_layout: mapping of pane attribute name -> list of ratios (one per child)
        Returns final sash positions (pixel) mapping similar to restore_layout.
        """
        px_layout: Dict[str, list] = {}
        for name, ratios in ratio_layout.items():
            pane = getattr(self, name, None)
            if not pane or not isinstance(pane, tk.PanedWindow):
                continue
            try:
                pane.update_idletasks()
            except Exception:
                pass
            try:
                orient = pane.cget("orient")
            except Exception:
                orient = "horizontal"
            total = 0
            try:
                if orient == "horizontal":
                    total = pane.winfo_width() or self.winfo_width() or 1000
                else:
                    total = pane.winfo_height() or self.winfo_height() or 800
            except Exception:
                total = 1000
            # normalize
            s = sum(ratios) if ratios else 0.0
            if s <= 0:
                continue
            norms = [float(r) / s for r in ratios]
            cum = 0.0
            poses: list = []
            for r in norms[:-1]:
                cum += r
                poses.append(int(round(cum * total)))
            px_layout[name] = poses

        # Delegate to pixel-based restore
        results = self.restore_layout(px_layout, attempts=attempts, delay=delay)

        # As a final touch, set child widths/heights according to ratios
        for name, ratios in ratio_layout.items():
            pane = getattr(self, name, None)
            if not pane or not isinstance(pane, tk.PanedWindow):
                continue
            try:
                children = pane.winfo_children()
                orient = pane.cget("orient")
                if orient == "horizontal":
                    total = pane.winfo_width() or self.winfo_width() or 1000
                    s = sum(ratios) or 1.0
                    sizes = [int(round(r / s * total)) for r in ratios]
                    for c, sz in zip(children, sizes):
                        try:
                            c.config(width=sz)
                        except Exception:
                            pass
                else:
                    total = pane.winfo_height() or self.winfo_height() or 800
                    s = sum(ratios) or 1.0
                    sizes = [int(round(r / s * total)) for r in ratios]
                    for c, sz in zip(children, sizes):
                        try:
                            c.config(height=sz)
                        except Exception:
                            pass
            except Exception:
                pass

        try:
            self.update()
        except Exception:
            pass
        return results

    def build_map(self, parent, height: int = 360) -> None:
        frame = tk.Frame(parent, bg=C["panel2"], height=height)
        frame.pack(fill="both", expand=True)
        frame.pack_propagate(False)

        # toolbar for map controls: destination entry and tile selector
        toolbar = tk.Frame(frame, bg=C["panel2"])
        toolbar.pack(fill="x", side="top")
        try:
            dest_btn = tk.Button(toolbar, text="HEDEF AYARLA", bg=C["panel2"], fg=C["text"], relief="flat", command=lambda: self._open_dest_dialog())
            dest_btn.pack(side="left", padx=(6, 6), pady=6)
        except Exception:
            pass
        try:
            tile_opts = ["Carto Dark", "Carto Light", "OpenStreetMap", "Stamen Toner", "Esri Satellite"]
            self._map_tile_var = tk.StringVar(value=tile_opts[0])
            tile_cb = ttk.Combobox(toolbar, values=tile_opts, textvariable=self._map_tile_var, state="readonly", width=20)
            tile_cb.pack(side="right", padx=(6, 8), pady=6)
            def _on_tile_change(_e=None):
                try:
                    self._set_tile_server(self._map_tile_var.get())
                except Exception:
                    pass
            tile_cb.bind("<<ComboboxSelected>>", _on_tile_change)
        except Exception:
            pass
        if tkintermapview:
            try:
                self.map_widget = tkintermapview.TkinterMapView(frame, corner_radius=0)
                self.map_widget.pack(fill="both", expand=True)
                # Initial map view is only a view center, not fake rover telemetry.
                # Dark tiles are used only for visual style; telemetry is still real-data only.
                try:
                    self.map_widget.set_tile_server(
                        "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png",
                        max_zoom=20,
                    )
                except Exception:
                    pass
                self.map_widget.set_position(39.7469865, 30.4740988)
                self.map_widget.set_zoom(18)
                # markers and paths
                self.map_marker = None
                self.map_path = None
                self.dest_marker = None
                self.dest_path = None
                self.destination = None
                # bind click-to-set if possible (try canvas or widget-level binding)
                try:
                    if hasattr(self.map_widget, "canvas"):
                        try:
                            self.map_widget.canvas.bind("<Button-1>", lambda e: self._on_map_click(e))
                        except Exception:
                            try:
                                self.map_widget.bind("<Button-1>", lambda e: self._on_map_click(e))
                            except Exception:
                                pass
                    else:
                        try:
                            self.map_widget.bind("<Button-1>", lambda e: self._on_map_click(e))
                        except Exception:
                            pass
                except Exception:
                    pass
            except Exception as exc:
                self.map_widget = None
                self.build_fallback_map(frame, f"Map error: {exc}")
        else:
            self.map_widget = None
            self.build_fallback_map(frame, "tkintermapview not installed")

    def build_fallback_map(self, parent, note: str) -> None:
        self.fallback_map = tk.Canvas(parent, bg=C["graph_bg"], highlightthickness=0)
        self.fallback_map.pack(fill="both", expand=True)
        try:
            self.fallback_map.bind("<Button-1>", lambda e: self._on_fallback_map_click(e))
        except Exception:
            pass
        self.fallback_map_note = note
        self.draw_fallback_map()

    def _populate_vehicle_status(self, body):
        self.vehicle_state = MetricBox(body, "Rover State", "WAITING", C["warn"])
        self.vehicle_state.grid(row=0, column=0, sticky="ew", padx=3, pady=3)
        self.mission_state = MetricBox(body, "Mission State", "MANUAL TEST", C["accent2"])
        self.mission_state.grid(row=0, column=1, sticky="ew", padx=3, pady=3)
        self.armed_state = MetricBox(body, "Armed", "SAFE", C["warn"])
        self.armed_state.grid(row=1, column=0, sticky="ew", padx=3, pady=3)
        self.health_state = MetricBox(body, "Health", "NO DATA", C["warn"])
        self.health_state.grid(row=1, column=1, sticky="ew", padx=3, pady=3)
        self.distance_state = MetricBox(body, "Distance", "0.0 m", C["text"])
        self.distance_state.grid(row=2, column=0, sticky="ew", padx=3, pady=3)
        self.packet_state = MetricBox(body, "Packets", "0", C["text"])
        self.packet_state.grid(row=2, column=1, sticky="ew", padx=3, pady=3)
        body.grid_columnconfigure(0, weight=1)
        body.grid_columnconfigure(1, weight=1)

    def build_vehicle_status(self, parent):
        card = Card(
            parent,
            "VEHICLE STATUS",
            detachable=True,
            rebuild_callback=self._populate_vehicle_status,
            swap_attrs=("vehicle_state", "mission_state", "armed_state", "health_state", "distance_state", "packet_state"),
        )
        self._populate_vehicle_status(card.body)
        return card

    def _populate_command_control(self, body):
        body.grid_columnconfigure(0, weight=1)

        serial_row = tk.Frame(body, bg=C["panel"])
        serial_row.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        serial_row.grid_columnconfigure(0, weight=1)
        self.port_combo = ttk.Combobox(serial_row, state="readonly", width=16)
        self.port_combo.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.btn(serial_row, "⟳", self.refresh_ports, width=3).grid(row=0, column=1, padx=3)
        self.connect_btn = self.btn(serial_row, "CONNECT", self.toggle_serial, width=12)
        self.connect_btn.grid(row=0, column=2, padx=(3, 0))

        mode_row = tk.Frame(body, bg=C["panel"])
        mode_row.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        for idx, mode in enumerate(["MANUAL", "TEST", "HEADING HOLD", "GPS TARGET", "SAFE"]):
            mode_row.grid_columnconfigure(idx, weight=1)
            self.btn(mode_row, mode, lambda m=mode: self.set_mode(m), width=10, accent=(mode == self.mode)).grid(row=0, column=idx, sticky="ew", padx=2)

        control_zone = tk.Frame(body, bg=C["panel"])
        control_zone.grid(row=2, column=0, sticky="ew")
        control_zone.grid_columnconfigure(0, weight=3)
        control_zone.grid_columnconfigure(1, weight=4)

        left_panel = tk.Frame(control_zone, bg=C["panel2"], highlightthickness=1, highlightbackground=C["line_soft"], padx=10, pady=9)
        left_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        tk.Label(left_panel, text="SPEED CONTROL", bg=C["panel2"], fg=C["muted"], font=("Consolas", 8, "bold")).pack(anchor="w")
        speeds = tk.Frame(left_panel, bg=C["panel2"])
        speeds.pack(fill="x", pady=(6, 10))
        self.btn(speeds, "0.2", lambda: self.send_command("1", force=True), width=6).pack(side="left", padx=2, expand=True, fill="x")
        self.btn(speeds, "0.5", lambda: self.send_command("2", force=True), width=6, accent=self.last_cmd == "2").pack(side="left", padx=2, expand=True, fill="x")
        self.btn(speeds, "1.0", lambda: self.send_command("3", force=True), width=6).pack(side="left", padx=2, expand=True, fill="x")
        tk.Label(left_panel, text="Manual driving only. Backend and serial protocol preserved.", bg=C["panel2"], fg=C["muted"], font=("Consolas", 8), wraplength=220, justify="left").pack(anchor="w")
        self.btn(left_panel, "EMERGENCY STOP", lambda: self.send_command("S", force=True), danger=True).pack(fill="x", pady=(12, 0))

        right_panel = tk.Frame(control_zone, bg=C["panel2"], highlightthickness=1, highlightbackground=C["line_soft"], padx=10, pady=9)
        right_panel.grid(row=0, column=1, sticky="nsew")
        tk.Label(right_panel, text="MOVEMENT CONTROL", bg=C["panel2"], fg=C["muted"], font=("Consolas", 8, "bold")).pack(anchor="w")
        self.build_dpad_canvas(right_panel).pack(pady=(8, 6))
        tk.Label(
            right_panel,
            text="Keys: Arrow keys   |   Space = STOP   |   1 / 2 / 3 speed",
            bg=C["panel2"], fg=C["muted"], font=("Consolas", 8),
        ).pack(anchor="center", pady=(4, 0))

    def build_command_control(self, parent):
        card = Card(
            parent,
            "COMMAND & CONTROL",
            detachable=True,
            rebuild_callback=self._populate_command_control,
            swap_attrs=("port_combo", "connect_btn"),
        )
        self._populate_command_control(card.body)
        return card

    def _populate_telemetry(self, b):
        self.row_lat = TelemetryRow(b, "GPS Latitude", "0.000000", "°")
        self.row_lon = TelemetryRow(b, "GPS Longitude", "0.000000", "°")
        self.row_speed = TelemetryRow(b, "Speed", "0.00", "km/h")
        self.row_yaw = TelemetryRow(b, "Heading / Yaw", "0.00", "°")
        self.row_acc = TelemetryRow(b, "Accel ax,ay,az", "0.00  0.00  0.00", "g")
        self.row_sat = TelemetryRow(b, "Satellites", "N/A", "")
        self.row_link = TelemetryRow(b, "Link Status", "WAITING", "")
        self.row_packet = TelemetryRow(b, "Packets RX", "0", "")
        self.row_age = TelemetryRow(b, "Last Data Age", "--", "ms")
        self.row_last = TelemetryRow(b, "Last Frame", "--", "")

    def build_telemetry_card(self, parent):
        card = Card(
            parent,
            "TELEMETRY",
            detachable=True,
            rebuild_callback=self._populate_telemetry,
            swap_attrs=("row_lat", "row_lon", "row_speed", "row_yaw", "row_acc", "row_sat", "row_link", "row_packet", "row_age", "row_last"),
        )
        self._populate_telemetry(card.body)
        return card

    def build_dashboard_graphs(self, parent) -> None:
        grid = tk.Frame(parent, bg=C["panel"])
        grid.pack(fill="both", expand=True)
        for col in range(3):
            grid.grid_columnconfigure(col, weight=1)
        self.graph_yaw = CanvasGraph(grid, "YAW vs TIME", height=135)
        self.graph_yaw.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)
        self.graph_acc = CanvasGraph(grid, "ACCELERATION", height=135)
        self.graph_acc.grid(row=0, column=1, sticky="nsew", padx=4, pady=4)
        self.graph_speed = CanvasGraph(grid, "SPEED vs TIME", height=135)
        self.graph_speed.grid(row=0, column=2, sticky="nsew", padx=4, pady=4)
        self.graph_path = CanvasGraph(grid, "IMU / GPS PATH", height=135)
        self.graph_path.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.graph_error = CanvasGraph(grid, "DRIFT / ERROR", height=135)
        self.graph_error.grid(row=1, column=1, sticky="nsew", padx=4, pady=4)
        self.graph_filter = CanvasGraph(grid, "FILTER COMPARISON (Yaw)", height=135)
        self.graph_filter.grid(row=1, column=2, sticky="nsew", padx=4, pady=4)

    def _populate_filter_lab(self, parent):
        modes = tk.Frame(parent, bg=C["panel"])
        modes.pack(fill="x")
        for mode in ["RAW", "LOW PASS", "MOVING AVG", "KALMAN 1D"]:
            tk.Radiobutton(modes, text=mode, value=mode, variable=self.filter_mode, command=lambda: self.log_event("INFO", f"Filter view: {self.filter_mode.get()}"), bg=C["panel"], fg=C["text_soft"], selectcolor=C["panel2"], activebackground=C["panel"], activeforeground=C["text"], font=("Consolas", 8)).pack(side="left", padx=3)
        self.slider_row(parent, "Low-pass alpha", self.lowpass_alpha, 0.01, 1.0)
        self.slider_row(parent, "Moving avg window", self.ma_window, 1, 80, integer=True)
        self.slider_row(parent, "Kalman Q", self.kalman_q, 0.0001, 0.05)
        self.slider_row(parent, "Kalman R", self.kalman_r, 0.01, 5.0)
        tk.Label(parent, text="Not: Bu panel yalnız PC tarafı analiz/görselleştirme içindir. Firmware komutu değiştirmez.", bg=C["panel"], fg=C["muted"], font=("Consolas", 8), wraplength=420, justify="left").pack(anchor="w", pady=(8, 0))

    def build_filter_lab_card(self, parent):
        card = Card(
            parent,
            "FILTER LAB",
            detachable=True,
            rebuild_callback=self._populate_filter_lab,
            swap_attrs=("filter_mode", "lowpass_alpha", "ma_window", "kalman_q", "kalman_r"),
        )
        self._populate_filter_lab(card.body)
        return card

    def slider_row(self, parent, name, variable, frm, to, integer: bool = False) -> None:
        row = tk.Frame(parent, bg=C["panel"])
        row.pack(fill="x", pady=3)
        tk.Label(row, text=name, bg=C["panel"], fg=C["muted"], font=("Consolas", 8), width=18, anchor="w").pack(side="left")
        scale = tk.Scale(row, from_=frm, to=to, resolution=1 if integer else 0.001, orient="horizontal", variable=variable, bg=C["panel"], fg=C["text"], troughcolor=C["panel2"], activebackground=C["accent"], highlightthickness=0, length=190, showvalue=True)
        scale.pack(side="left", fill="x", expand=True)

    def _populate_troubleshooter(self, parent):
        grid = tk.Frame(parent, bg=C["panel"])
        grid.pack(fill="both", expand=True)
        labels = ["POWER", "IMU", "GPS", "COMM", "CMD TIMEOUT", "DATA RATE", "FAILSAFE", "SUMMARY"]
        self.diag: Dict[str, MetricBox] = {}
        for idx, label in enumerate(labels):
            box = MetricBox(grid, label, "WAIT", C["warn"])
            box.grid(row=idx // 4, column=idx % 4, sticky="nsew", padx=3, pady=3)
            grid.grid_columnconfigure(idx % 4, weight=1)
            self.diag[label] = box

    def build_troubleshooter_card(self, parent):
        card = Card(
            parent,
            "TROUBLESHOOTER",
            detachable=True,
            rebuild_callback=self._populate_troubleshooter,
            swap_attrs=("diag",),
        )
        self._populate_troubleshooter(card.body)
        return card

    def _populate_event_log(self, parent):
        self.event_text = tk.Text(parent, height=12, bg=C["graph_bg"], fg=C["text_soft"], insertbackground=C["text"], relief="flat", font=("Consolas", 9), padx=8, pady=8)
        self.event_text.pack(fill="both", expand=True)
        for line in self.event_lines[-MAX_LOG_LINES:]:
            self.event_text.insert("end", line)
        self.event_text.see("end")

    def build_event_log_card(self, parent):
        card = Card(
            parent,
            "EVENT LOG",
            detachable=True,
            rebuild_callback=self._populate_event_log,
            swap_attrs=("event_text", "event_lines"),
        )
        self._populate_event_log(card.body)
        return card

    def build_telemetry_page(self, parent) -> None:
        root = parent
        root.configure(bg=C["bg"])
        root.grid_columnconfigure(0, weight=1)
        self.build_telemetry_card(root).grid(row=0, column=0, sticky="nsew", padx=0, pady=0)

    def build_analysis_page(self, parent) -> None:
        root = parent
        root.configure(bg=C["bg"])
        root.grid_columnconfigure(0, weight=1)
        root.grid_columnconfigure(1, weight=1)
        root.grid_rowconfigure(0, weight=1)
        root.grid_rowconfigure(1, weight=1)
        self.analysis_yaw = CanvasGraph(root, "YAW vs TIME", height=260)
        self.analysis_yaw.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)
        self.analysis_acc = CanvasGraph(root, "ACCELERATION vs TIME", height=260)
        self.analysis_acc.grid(row=0, column=1, sticky="nsew", padx=4, pady=4)
        self.analysis_speed = CanvasGraph(root, "SPEED vs TIME", height=260)
        self.analysis_speed.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.analysis_filter = CanvasGraph(root, "FILTER COMPARISON", height=260)
        self.analysis_filter.grid(row=1, column=1, sticky="nsew", padx=4, pady=4)

    def build_filter_page(self, parent) -> None:
        root = parent
        root.configure(bg=C["bg"])
        root.grid_columnconfigure(0, weight=0)
        root.grid_columnconfigure(1, weight=1)
        self.build_filter_lab_card(root).grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self.filter_page_graph = CanvasGraph(root, "FILTERED YAW FROM REAL IMU DATA", height=500)
        self.filter_page_graph.grid(row=0, column=1, sticky="nsew")

    def build_troubleshooter_page(self, parent) -> None:
        root = parent
        root.configure(bg=C["bg"])
        root.grid_columnconfigure(0, weight=1)
        self.build_troubleshooter_card(root).grid(row=0, column=0, sticky="ew", pady=(0, 8))
        notes = Card(root, "DIAGNOSTIC NOTES")
        notes.grid(row=1, column=0, sticky="nsew")
        root.grid_rowconfigure(1, weight=1)
        self.diag_text = tk.Text(notes.body, bg=C["graph_bg"], fg=C["text_soft"], relief="flat", font=("Consolas", 10), padx=10, pady=10)
        self.diag_text.pack(fill="both", expand=True)

    def build_logs_page(self, parent) -> None:
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(0, weight=1)
        self.build_event_log_card(parent).grid(row=0, column=0, sticky="nsew")

    def build_dpad_canvas(self, parent):
        """Draw movement arrows on canvas so Windows font/glyph issues cannot break the UI."""
        w, h = 218, 166
        canvas = tk.Canvas(parent, width=w, height=h, bg=C["panel2"], highlightthickness=0)

        buttons = {
            "F": (84, 8, 134, 48, "up"),
            "L": (28, 62, 78, 102, "left"),
            "S": (84, 62, 134, 102, "stop"),
            "R": (140, 62, 190, 102, "right"),
            "B": (84, 116, 134, 156, "down"),
        }

        def draw_button(cmd: str, fill: str) -> None:
            x0, y0, x1, y1, kind = buttons[cmd]
            tag = f"dpad_{cmd}"
            outline = C["danger"] if cmd == "S" else C["line"]
            canvas.create_rectangle(x0, y0, x1, y1, fill=fill, outline=outline, width=1, tags=(tag,))
            cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
            if kind == "up":
                canvas.create_polygon(cx, y0 + 11, x0 + 15, y1 - 13, x1 - 15, y1 - 13, fill=C["text"], outline="", tags=(tag,))
            elif kind == "down":
                canvas.create_polygon(cx, y1 - 11, x0 + 15, y0 + 13, x1 - 15, y0 + 13, fill=C["text"], outline="", tags=(tag,))
            elif kind == "left":
                canvas.create_polygon(x0 + 11, cy, x1 - 13, y0 + 12, x1 - 13, y1 - 12, fill=C["text"], outline="", tags=(tag,))
            elif kind == "right":
                canvas.create_polygon(x1 - 11, cy, x0 + 13, y0 + 12, x0 + 13, y1 - 12, fill=C["text"], outline="", tags=(tag,))
            else:
                canvas.create_text(cx, cy, text="STOP", fill=C["text"], font=("Segoe UI", 8, "bold"), tags=(tag,))
            canvas.tag_bind(tag, "<Button-1>", lambda _e, c=cmd: self.send_command(c, force=True))
            canvas.tag_bind(tag, "<Enter>", lambda _e, t=tag, c=cmd: self._dpad_hover(canvas, t, c, True))
            canvas.tag_bind(tag, "<Leave>", lambda _e, t=tag, c=cmd: self._dpad_hover(canvas, t, c, False))

        for cmd in ["F", "L", "S", "R", "B"]:
            draw_button(cmd, C["danger_dark"] if cmd == "S" else C["panel3"])
        return canvas

    def _dpad_hover(self, canvas, tag: str, cmd: str, active: bool) -> None:
        fill = C["danger"] if cmd == "S" and active else C["danger_dark"] if cmd == "S" else C["accent"] if active else C["panel3"]
        for item in canvas.find_withtag(tag):
            if canvas.type(item) == "rectangle":
                canvas.itemconfigure(item, fill=fill)

    def nav_btn(self, parent, text, command, stop: bool = False):
        bg = C["danger_dark"] if stop else C["panel3"]
        active = C["danger"] if stop else C["accent"]
        return tk.Button(
            parent,
            text=text,
            command=command,
            width=4,
            height=1,
            bg=bg,
            fg=C["text"],
            activebackground=active,
            activeforeground=C["text"],
            relief="flat",
            bd=0,
            font=("Segoe UI Symbol", 14, "bold"),
            padx=8,
            pady=10,
            cursor="hand2",
        )

    def build_settings_page(self, parent) -> None:
        card = Card(parent, "SETTINGS")
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(0, weight=1)
        card.grid(row=0, column=0, sticky="nsew")
        tk.Label(card.body, text="Protocol preserved: TX = F/B/L/R/S/1/2/3 | RX = GPS:lat,lon,speed_kmph and IMU:yaw,ax,ay,az", bg=C["panel"], fg=C["text_soft"], font=FONT_MONO, wraplength=900, justify="left").pack(anchor="w")
        tk.Label(card.body, text="Bu sürüm veri uydurmaz. Telemetri alanları yalnız gerçek seri port verisi gelirse değişir.", bg=C["panel"], fg=C["warn"], font=FONT_MONO_BOLD, wraplength=900, justify="left").pack(anchor="w", pady=(10, 0))

    def btn(self, parent, text, command, width: int = 8, danger: bool = False, accent: bool = False, font=None, height=None):
        bg = C["danger_dark"] if danger else (C["accent"] if accent else C["panel2"])
        opts = dict(
            text=text, command=command, width=width, bg=bg, fg=C["text"],
            activebackground=C["danger"] if danger else C["accent2"],
            activeforeground=C["text"], relief="flat", bd=0,
            font=font or ("Segoe UI", 9, "bold"), padx=6, pady=6,
        )
        if height is not None:
            opts["height"] = height
        return tk.Button(parent, **opts)

    # ------------------------------------------------------------------
    # Serial / backend preserved
    # ------------------------------------------------------------------
    def refresh_ports(self) -> None:
        if not hasattr(self, "port_combo"):
            return
        if not self.serial.available:
            self.port_combo["values"] = ["pyserial yok"]
            self.port_combo.set("pyserial yok")
            return
        ports = self.serial.ports()
        self.port_combo["values"] = ports if ports else ["COM bulunamadı"]
        self.port_combo.set(ports[0] if ports else "COM bulunamadı")

    def toggle_serial(self) -> None:
        if self.serial.connected:
            self.disconnect_serial()
        else:
            self.connect_serial()

    def connect_serial(self) -> None:
        port = self.port_combo.get() if hasattr(self, "port_combo") else ""
        if not port or "bulunamadı" in port or "yok" in port:
            messagebox.showwarning("Port yok", "ESP32/NodeMCU USB bağlantısını ve COM portunu kontrol et.")
            return
        try:
            self.serial.connect(port)
            self.connect_btn.configure(text="DISCONNECT")
            self.tile_connection.set(f"● {port}", C["ok"])
            self.log_event("INFO", f"Connected: {port} @ {BAUD_RATE}")
        except Exception as exc:
            self.log_event("ERROR", f"Serial connect error: {exc}")
            messagebox.showerror("Seri port hatası", str(exc))

    def disconnect_serial(self) -> None:
        try:
            self.send_command("S", force=True)
        except Exception:
            pass
        self.serial.disconnect()
        if hasattr(self, "connect_btn"):
            self.connect_btn.configure(text="CONNECT")
        self.tile_connection.set("● DISCONNECTED", C["danger"])
        self.log_event("INFO", "Disconnected")

    def send_command(self, cmd: str, force: bool = False) -> None:
        if cmd not in COMMANDS:
            return
        if self.mode not in ["MANUAL", "TEST"] and cmd in "FBLR123":
            self.log_event("WARN", f"Command blocked in {self.mode} mode: {cmd}")
            return
        if not force and cmd == self.last_cmd:
            return
        self.last_cmd = cmd
        if cmd in "FBLR":
            self.last_motion_cmd_ms = self.now_ms()
        try:
            sent = self.serial.send(cmd)
            if sent:
                self.log_event("TX", f"> {cmd} [{COMMANDS[cmd]}]")
            else:
                self.log_event("WARN", f"Not connected. Command not sent: {cmd} [{COMMANDS[cmd]}]")
        except Exception as exc:
            self.log_event("ERROR", f"TX error: {exc}")
        self.update_command_visual(cmd)

    def process_rx_line(self, line: str) -> None:
        self.telemetry.last_line = line
        now = self.now_ms()
        if line.startswith("GPS:"):
            try:
                p = line.split(":", 1)[1].split(",")
                lat, lon = float(p[0]), float(p[1])
                speed = float(p[2]) if len(p) >= 3 else 0.0
                self.update_gps(lat, lon, speed, now)
            except Exception:
                self.log_event("WARN", f"Bad GPS frame: {line}")
        elif line.startswith("IMU:"):
            try:
                p = line.split(":", 1)[1].split(",")
                self.telemetry.yaw_deg = float(p[0])
                if len(p) >= 4:
                    self.telemetry.ax_g = float(p[1])
                    self.telemetry.ay_g = float(p[2])
                    self.telemetry.az_g = float(p[3])
                self.mark_rx(now, imu=True)
            except Exception:
                self.log_event("WARN", f"Bad IMU frame: {line}")
        elif line.startswith("ERR:"):
            self.log_event("ERROR", line)
        else:
            self.log_event("RX", f"< {line}")

    def update_gps(self, lat: float, lon: float, speed: float, now_ms: int) -> None:
        if self.prev_lat and self.prev_lon and self.last_cmd != "S":
            d = self.haversine(self.prev_lat, self.prev_lon, lat, lon)
            if d < 20.0:
                self.telemetry.distance_m += d
        self.prev_lat, self.prev_lon = lat, lon
        self.telemetry.lat = lat
        self.telemetry.lon = lon
        self.telemetry.speed_kmph = speed
        self.telemetry.gps_fix = bool(lat and lon)
        self.path_points.append((lat, lon))
        self.path_points = self.path_points[-500:]
        self.mark_rx(now_ms, gps=True)
        self.update_map_position(lat, lon)

    def mark_rx(self, now_ms: int, gps: bool = False, imu: bool = False) -> None:
        self.telemetry.packets += 1
        self.telemetry.last_rx_ms = now_ms
        if gps:
            self.telemetry.last_gps_ms = now_ms
        if imu:
            self.telemetry.last_imu_ms = now_ms
        self.history.append(time.time() - self.t0, self.telemetry)

    # ------------------------------------------------------------------
    # UI updates
    # ------------------------------------------------------------------
    def ui_loop(self) -> None:
        while not self.serial.rx_queue.empty():
            self.process_rx_line(self.serial.rx_queue.get())

        if self.last_cmd in "FBLR" and self.now_ms() - self.last_motion_cmd_ms > COMMAND_DEADMAN_MS:
            self.send_command("S", force=True)
            self.log_event("WARN", "PC deadman stop: command timeout")

        self.update_status_tiles()
        self.update_telemetry_widgets()
        self.update_graph_widgets()
        self.update_diagnostics()
        if hasattr(self, "fallback_map"):
            self.draw_fallback_map()
        self.after(UI_REFRESH_MS, self.ui_loop)

    def update_status_tiles(self) -> None:
        now = self.now_ms()
        age = now - self.telemetry.last_rx_ms if self.telemetry.last_rx_ms else 999999
        connected = self.serial.connected
        if connected:
            self.tile_connection.set("● CONNECTED", C["ok"])
        else:
            self.tile_connection.set("● DISCONNECTED", C["danger"])
        self.tile_mode.set(f"◇ {self.mode}", C["accent2"] if self.mode != "SAFE" else C["warn"])
        gps_text = "3D FIX" if self.telemetry.gps_fix else "NO FIX"
        self.tile_gps.set(gps_text, C["ok"] if self.telemetry.gps_fix else C["warn"])
        self.tile_cmd.set(COMMANDS.get(self.last_cmd, self.last_cmd), C["danger"] if self.last_cmd == "S" else C["accent2"])
        self.tile_power.set("UNKNOWN", C["warn"])
        self.tile_log.set("OFF", C["muted"])
        self.tile_time.set(time.strftime("%H:%M:%S"), C["text_soft"])
        session = int(time.time() - self.t0)
        self.tile_session.set(f"{session//3600:02d}:{(session%3600)//60:02d}:{session%60:02d}", C["text_soft"])
        if hasattr(self, "vehicle_state"):
            self.vehicle_state.set("ACTIVE" if age < TELEMETRY_STALE_MS else "WAITING", C["ok"] if age < TELEMETRY_STALE_MS else C["warn"])
            self.armed_state.set("ARMED" if connected and self.mode != "SAFE" else "SAFE", C["ok"] if connected and self.mode != "SAFE" else C["warn"])
            self.health_state.set("HEALTHY" if age < TELEMETRY_STALE_MS else "NO DATA", C["ok"] if age < TELEMETRY_STALE_MS else C["warn"])
            self.distance_state.set(f"{self.telemetry.distance_m:.1f} m")
            self.packet_state.set(str(self.telemetry.packets))

    def update_telemetry_widgets(self) -> None:
        now = self.now_ms()
        age = now - self.telemetry.last_rx_ms if self.telemetry.last_rx_ms else 0
        if hasattr(self, "row_lat"):
            self.row_lat.set(f"{self.telemetry.lat:.6f}")
            self.row_lon.set(f"{self.telemetry.lon:.6f}")
            self.row_speed.set(f"{self.telemetry.speed_kmph:.2f}")
            self.row_yaw.set(f"{self.telemetry.yaw_deg:.2f}")
            self.row_acc.set(f"{self.telemetry.ax_g:+.2f}  {self.telemetry.ay_g:+.2f}  {self.telemetry.az_g:+.2f}")
            self.row_link.set("LIVE" if age and age < TELEMETRY_STALE_MS else "WAITING", C["ok"] if age and age < TELEMETRY_STALE_MS else C["warn"])
            self.row_packet.set(str(self.telemetry.packets))
            self.row_age.set(str(age) if self.telemetry.last_rx_ms else "--")
            last = self.telemetry.last_line if len(self.telemetry.last_line) < 32 else self.telemetry.last_line[:29] + "..."
            self.row_last.set(last or "--")

    def update_graph_widgets(self) -> None:
        x = list(self.history.t)
        yaw = list(self.history.yaw)
        speed = list(self.history.speed)
        ax = list(self.history.ax)
        ay = list(self.history.ay)
        az = list(self.history.az)
        filtered = self.filtered_yaw_series(yaw)
        for graph_name in ["graph_yaw", "analysis_yaw"]:
            if hasattr(self, graph_name):
                getattr(self, graph_name).update_series(x, {"yaw": yaw}, fixed_ylim=(-180, 180))
        for graph_name in ["graph_acc", "analysis_acc"]:
            if hasattr(self, graph_name):
                getattr(self, graph_name).update_series(x, {"ax": ax, "ay": ay, "az": az}, fixed_ylim=(-2.5, 2.5))
        for graph_name in ["graph_speed", "analysis_speed"]:
            if hasattr(self, graph_name):
                getattr(self, graph_name).update_series(x, {"speed": speed})
        for graph_name in ["graph_filter", "analysis_filter", "filter_page_graph"]:
            if hasattr(self, graph_name):
                getattr(self, graph_name).update_series(x, {"raw": yaw, self.filter_mode.get(): filtered}, fixed_ylim=(-180, 180))
        if hasattr(self, "graph_error"):
            zeros = [0.0 for _ in x]
            self.graph_error.update_series(x, {"error": zeros})
        if hasattr(self, "graph_path"):
            self.graph_path.update_series([], {})

    def filtered_yaw_series(self, yaw: List[float]) -> List[float]:
        mode = self.filter_mode.get()
        if mode == "LOW PASS":
            return low_pass(yaw, self.lowpass_alpha.get())
        if mode == "MOVING AVG":
            return moving_average(yaw, self.ma_window.get())
        if mode == "KALMAN 1D":
            return kalman_1d(yaw, self.kalman_q.get(), self.kalman_r.get())
        return list(yaw)

    def update_diagnostics(self) -> None:
        now = self.now_ms()
        age = now - self.telemetry.last_rx_ms if self.telemetry.last_rx_ms else 999999
        imu_age = now - self.telemetry.last_imu_ms if self.telemetry.last_imu_ms else 999999
        gps_age = now - self.telemetry.last_gps_ms if self.telemetry.last_gps_ms else 999999
        if hasattr(self, "diag") and "POWER" in self.diag:
            self.diag["POWER"].set("UNKNOWN", C["warn"])
            self.diag["IMU"].set("OK" if imu_age < TELEMETRY_STALE_MS else "WAIT", C["ok"] if imu_age < TELEMETRY_STALE_MS else C["warn"])
            self.diag["GPS"].set("FIX" if self.telemetry.gps_fix and gps_age < 5000 else "NO FIX", C["ok"] if self.telemetry.gps_fix and gps_age < 5000 else C["warn"])
            self.diag["COMM"].set("OK" if self.serial.connected else "OFF", C["ok"] if self.serial.connected else C["danger"])
            self.diag["CMD TIMEOUT"].set("OK" if self.last_cmd == "S" or self.now_ms() - self.last_motion_cmd_ms < COMMAND_DEADMAN_MS else "STOP", C["ok"])
            self.diag["DATA RATE"].set("LIVE" if age < TELEMETRY_STALE_MS else "WAIT", C["ok"] if age < TELEMETRY_STALE_MS else C["warn"])
            self.diag["FAILSAFE"].set("PC ON", C["ok"])
            self.diag["SUMMARY"].set("0 ERR" if age < TELEMETRY_STALE_MS or not self.serial.connected else "STALE", C["ok"] if age < TELEMETRY_STALE_MS or not self.serial.connected else C["warn"])
        if hasattr(self, "diag_text"):
            self.diag_text.delete("1.0", "end")
            self.diag_text.insert("end", "Katmanlı kontrol mantığı:\n")
            self.diag_text.insert("end", f"- Seri bağlantı: {'OK' if self.serial.connected else 'OFF'}\n")
            self.diag_text.insert("end", f"- IMU veri yaşı: {'--' if imu_age == 999999 else imu_age} ms\n")
            self.diag_text.insert("end", f"- GPS veri yaşı: {'--' if gps_age == 999999 else gps_age} ms\n")
            self.diag_text.insert("end", f"- Genel veri yaşı: {'--' if age == 999999 else age} ms\n")
            self.diag_text.insert("end", "- Güç/batarya değeri UI tarafına gelmiyor; firmware'e voltaj telemetrisi eklenirse burada gerçek değer gösterilir.\n")
            self.diag_text.insert("end", "- Bu ekran veri uydurmaz; yalnız alınan seri paketlerden durum çıkarır.\n")

    def update_map_position(self, lat: float, lon: float) -> None:
        if getattr(self, "map_widget", None):
            try:
                self.map_widget.set_position(lat, lon)
                if self.map_marker is None:
                    self.map_marker = self.map_widget.set_marker(lat, lon, text="ROVER")
                else:
                    self.map_marker.set_position(lat, lon)
                if len(self.path_points) >= 2:
                    if self.map_path:
                        try:
                            self.map_path.delete()
                        except Exception:
                            pass
                    self.map_path = self.map_widget.set_path(self.path_points)
                # update destination path if destination exists
                if getattr(self, 'destination', None):
                    try:
                        if getattr(self, 'dest_path', None):
                            try:
                                self.dest_path.delete()
                            except Exception:
                                pass
                        dest = self.destination
                        if dest and isinstance(dest, (list, tuple)) and len(dest) >= 2:
                            self.dest_path = self.map_widget.set_path([(lat, lon), (float(dest[0]), float(dest[1]))])
                    except Exception:
                        pass
            except Exception as exc:
                self.log_event("WARN", f"Map update error: {exc}")

    # ------------------ Map destination and tile helpers ------------------
    def _open_dest_dialog(self) -> None:
        """Prompt user for lat/lon and set destination marker."""
        try:
            lat = simpledialog.askfloat("Hedef Latitude", "Latitude:", parent=self)
            if lat is None:
                return
            lon = simpledialog.askfloat("Hedef Longitude", "Longitude:", parent=self)
            if lon is None:
                return
            self.set_map_destination(float(lat), float(lon))
        except Exception:
            pass

    def set_map_destination(self, lat: float, lon: float, text: str = "DEST") -> None:
        """Place or move a destination marker on the map, and draw a line from rover."""
        if not getattr(self, 'map_widget', None):
            return
        try:
            # remove previous dest marker if any
            if getattr(self, 'dest_marker', None):
                try:
                    self.dest_marker.delete()
                except Exception:
                    pass
            self.dest_marker = self.map_widget.set_marker(lat, lon, text=text)
            self.destination = (float(lat), float(lon))
            # draw path from current rover position to destination
            try:
                if getattr(self, 'dest_path', None):
                    try:
                        self.dest_path.delete()
                    except Exception:
                        pass
                cur_lat = getattr(self, 'telemetry', None).lat if getattr(self, 'telemetry', None) else None
                cur_lon = getattr(self, 'telemetry', None).lon if getattr(self, 'telemetry', None) else None
                if cur_lat is not None and cur_lon is not None:
                    self.dest_path = self.map_widget.set_path([(cur_lat, cur_lon), (float(lat), float(lon))])
            except Exception:
                pass
        except Exception:
            pass

    def clear_map_destination(self) -> None:
        try:
            if getattr(self, 'dest_marker', None):
                try:
                    self.dest_marker.delete()
                except Exception:
                    pass
            if getattr(self, 'dest_path', None):
                try:
                    self.dest_path.delete()
                except Exception:
                    pass
            self.dest_marker = None
            self.dest_path = None
            self.destination = None
        except Exception:
            pass

    def _set_tile_server(self, key: str) -> None:
        """Switch tile server by friendly key."""
        if not getattr(self, 'map_widget', None):
            return
        tiles = {
            'Carto Dark': 'https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png',
            'Carto Light': 'https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png',
            'OpenStreetMap': 'https://a.tile.openstreetmap.org/{z}/{x}/{y}.png',
            'Stamen Toner': 'http://tile.stamen.com/toner/{z}/{x}/{y}.png',
            'Esri Satellite': 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        }
        url = tiles.get(key)
        if not url:
            return
        try:
            try:
                self.map_widget.set_tile_server(url, max_zoom=20)
            except TypeError:
                # some builds accept only a single arg
                try:
                    self.map_widget.set_tile_server(url)
                except Exception:
                    pass
        except Exception:
            pass

    def _on_map_click(self, event) -> None:
        """Handle left-click on map_widget; try multiple conversion APIs, fallback to dialog."""
        if not getattr(self, 'map_widget', None):
            return
        lat = None
        lon = None
        x = getattr(event, 'x', None)
        y = getattr(event, 'y', None)
        # Try several possible API names that different versions may expose
        candidates = [
            'convert_canvas_coords_to_decimal',
            'canvas_coords_to_decimal',
            'convert_pixel_to_geo',
            'convert_canvas_coords_to_geo',
            'get_position_from_xy',
            'get_position_by_xy',
            'get_position_from_pixel',
            'get_position_at_pixel',
            'get_pos_at_xy',
            'xy_to_latlon',
            'get_coordinates',
            'get_position',
        ]
        for name in candidates:
            fn = getattr(self.map_widget, name, None)
            if not callable(fn):
                continue
            try:
                # many of these expect (x, y)
                res = None
                try:
                    res = fn(x, y)
                except TypeError:
                    try:
                        res = fn()
                    except Exception:
                        res = None
                if res and isinstance(res, (tuple, list)) and len(res) >= 2:
                    try:
                        lat = float(res[0])
                        lon = float(res[1])
                        break
                    except Exception:
                        pass
            except Exception:
                continue

        # fallback: try get_position() as center guess
        if lat is None:
            try:
                fnc = getattr(self.map_widget, 'get_position', None)
                if callable(fnc):
                    p = fnc()
                    if p and isinstance(p, (tuple, list)) and len(p) >= 2:
                        lat, lon = float(p[0]), float(p[1])
            except Exception:
                pass

        # if still unknown, open manual dialog
        if lat is None or lon is None:
            try:
                self._open_dest_dialog()
                return
            except Exception:
                return

        # set destination marker from click
        try:
            self.set_map_destination(lat, lon, text='DEST (click)')
        except Exception:
            try:
                self._open_dest_dialog()
            except Exception:
                pass

    def _on_fallback_map_click(self, event) -> None:
        c = getattr(self, 'fallback_map', None)
        if not c:
            return
        try:
            w = max(300, c.winfo_width())
            h = max(220, c.winfo_height())
            if len(self.path_points) < 2:
                # cannot compute mapping reliably, ask user
                self._open_dest_dialog()
                return
            lats = [p[0] for p in self.path_points]
            lons = [p[1] for p in self.path_points]
            lat_min, lat_max = min(lats), max(lats)
            lon_min, lon_max = min(lons), max(lons)
            x_rel = event.x
            y_rel = event.y
            lon = lon_min + (lon_max - lon_min) * (x_rel / float(w))
            lat = lat_max - (lat_max - lat_min) * (y_rel / float(h))
            self.set_map_destination(lat, lon, text='DEST (click)')
        except Exception:
            try:
                self._open_dest_dialog()
            except Exception:
                pass

    def draw_fallback_map(self) -> None:
        c = getattr(self, "fallback_map", None)
        if not c:
            return
        c.delete("all")
        w = max(300, c.winfo_width())
        h = max(220, c.winfo_height())
        for x in range(0, w, 40):
            c.create_line(x, 0, x, h, fill=C["line_soft"])
        for y in range(0, h, 40):
            c.create_line(0, y, w, y, fill=C["line_soft"])
        c.create_text(12, 12, text="FALLBACK MAP - REAL GPS ONLY", fill=C["text"], font=FONT_MONO_BOLD, anchor="nw")
        c.create_text(12, 34, text=getattr(self, "fallback_map_note", ""), fill=C["muted"], font=("Consolas", 8), anchor="nw")
        if len(self.path_points) < 2:
            c.create_text(w/2, h/2, text="GPS PATH WAITING", fill=C["muted"], font=FONT_MONO_BOLD)
            return
        lats = [p[0] for p in self.path_points]
        lons = [p[1] for p in self.path_points]
        lat_min, lat_max = min(lats), max(lats)
        lon_min, lon_max = min(lons), max(lons)
        pts = []
        for lat, lon in self.path_points:
            x = 40 + (lon - lon_min) / max(1e-9, lon_max - lon_min) * (w - 80)
            y = h - 40 - (lat - lat_min) / max(1e-9, lat_max - lat_min) * (h - 80)
            pts.extend([x, y])
        if len(pts) >= 4:
            c.create_line(*pts, fill=C["plot1"], width=2)
            c.create_oval(pts[-2]-5, pts[-1]-5, pts[-2]+5, pts[-1]+5, fill=C["ok"], outline="")

    def set_mode(self, mode: str) -> None:
        self.mode = mode
        if mode == "SAFE":
            self.send_command("S", force=True)
        self.log_event("INFO", f"Mode set: {mode}")
        # Rebuild command card only if dashboard visible, so active button color updates.
        if self.current_page == "Dashboard":
            self.show_page("Dashboard")

    def update_command_visual(self, cmd: str) -> None:
        self.tile_cmd.set(COMMANDS.get(cmd, cmd), C["danger"] if cmd == "S" else C["accent2"])

    def log_event(self, level: str, msg: str) -> None:
        stamp = time.strftime("%H:%M:%S")
        line = f"{stamp}  {level:<5}  {msg}\n"
        self.event_lines.append(line)
        if len(self.event_lines) > MAX_LOG_LINES:
            self.event_lines = self.event_lines[-MAX_LOG_LINES:]
        if hasattr(self, "event_text") and self.event_text.winfo_exists():
            self.event_text.insert("end", line)
            lines = int(self.event_text.index("end-1c").split(".")[0])
            if lines > MAX_LOG_LINES:
                self.event_text.delete("1.0", f"{lines - MAX_LOG_LINES}.0")
            self.event_text.see("end")

    # ------------------------------------------------------------------
    # Keyboard and utilities
    # ------------------------------------------------------------------
    def bind_keys(self) -> None:
        self.bind("<KeyPress>", self.on_key_press)
        self.bind("<KeyRelease>", self.on_key_release)
        self.focus_set()

    def on_key_press(self, event) -> None:
        keymap = {"Up": "F", "Down": "B", "Left": "L", "Right": "R", "space": "S", "1": "1", "2": "2", "3": "3"}
        cmd = keymap.get(event.keysym)
        if cmd:
            self.pressed_keys.add(event.keysym)
            self.send_command(cmd)

    def on_key_release(self, event) -> None:
        if event.keysym in self.pressed_keys:
            self.pressed_keys.remove(event.keysym)
        if event.keysym in ["Up", "Down", "Left", "Right"]:
            self.send_command("S", force=True)

    @staticmethod
    def now_ms() -> int:
        return int(time.time() * 1000)

    @staticmethod
    def haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        radius_m = 6371000.0
        p1, p2 = math.radians(lat1), math.radians(lat2)
        dp = math.radians(lat2 - lat1)
        dl = math.radians(lon2 - lon1)
        a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
        return 2 * radius_m * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    def on_close(self) -> None:
        try:
            self.send_command("S", force=True)
            self.serial.disconnect()
        finally:
            self.destroy()


def main() -> None:
    app = RoverGCSApp()
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()

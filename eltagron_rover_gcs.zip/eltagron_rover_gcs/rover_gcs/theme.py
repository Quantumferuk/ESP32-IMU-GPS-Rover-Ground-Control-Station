"""Corporate aerospace color/theme constants for Eltagron Rover GCS."""

THEME = {
    "bg": "#0A1220",
    "bg2": "#0D1726",
    "panel": "#0F1A28",
    "panel2": "#132131",
    "panel3": "#182A3F",
    "line": "#23405E",
    "line_soft": "#18293D",
    "text": "#E6EDF5",
    "text_soft": "#C7D2E0",
    "muted": "#8A97A8",
    "accent": "#3B82F6",
    "accent2": "#60A5FA",
    "ok": "#22C55E",
    "warn": "#F59E0B",
    "danger": "#EF4444",
    "danger_dark": "#991B1B",
    "graph_grid": "#26364A",
    "graph_bg": "#0C1623",
    "plot1": "#60A5FA",
    "plot2": "#34D399",
    "plot3": "#F59E0B",
    "plot4": "#A78BFA",
    "plot5": "#F87171",
}

FONT_TITLE = ("Segoe UI", 12, "bold")
FONT_BODY = ("Segoe UI", 10)
FONT_SMALL = ("Segoe UI", 9)
FONT_MONO = ("Consolas", 10)
FONT_MONO_BOLD = ("Consolas", 10, "bold")

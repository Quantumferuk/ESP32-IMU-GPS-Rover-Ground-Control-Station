"""Lightweight analysis filters. These filters do not change firmware commands."""
from __future__ import annotations
from typing import Iterable, List


def moving_average(values: Iterable[float], window: int = 10) -> List[float]:
    vals = list(values)
    window = max(1, int(window))
    if not vals:
        return []
    out: List[float] = []
    running = 0.0
    q: List[float] = []
    for v in vals:
        q.append(float(v))
        running += float(v)
        if len(q) > window:
            running -= q.pop(0)
        out.append(running / len(q))
    return out


def low_pass(values: Iterable[float], alpha: float = 0.15) -> List[float]:
    vals = list(values)
    if not vals:
        return []
    alpha = max(0.001, min(1.0, float(alpha)))
    y = float(vals[0])
    out = [y]
    for x in vals[1:]:
        y = alpha * float(x) + (1.0 - alpha) * y
        out.append(y)
    return out


def kalman_1d(values: Iterable[float], q: float = 0.001, r: float = 0.5) -> List[float]:
    vals = list(values)
    if not vals:
        return []
    q = max(1e-9, float(q))
    r = max(1e-9, float(r))
    x = float(vals[0])
    p = 1.0
    out = []
    for z in vals:
        p += q
        k = p / (p + r)
        x = x + k * (float(z) - x)
        p = (1.0 - k) * p
        out.append(x)
    return out

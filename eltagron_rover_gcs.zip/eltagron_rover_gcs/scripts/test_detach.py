#!/usr/bin/env python3
import os
import sys
import time
import traceback

# Ensure project root is on sys.path when running from scripts/
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from rover_gcs.app import RoverGCSApp
from rover_gcs.widgets import Card


def find_cards(w):
    res = []
    try:
        for child in w.winfo_children():
            try:
                if isinstance(child, Card):
                    res.append(child)
            except Exception:
                pass
            res.extend(find_cards(child))
    except Exception:
        pass
    return res


def main():
    app = None
    try:
        app = RoverGCSApp()
        app.update()
        frame = app.page_frames.get("Dashboard")
        if not frame:
            print("Dashboard frame not found", flush=True)
            app.destroy()
            return
        cards = find_cards(frame)
        print(f"Found {len(cards)} cards:", [getattr(c, '_title', str(c)) for c in cards], flush=True)
        for c in cards:
            title = getattr(c, '_title', None) or repr(c)
            print(f"Testing detach/dock for: {title}", flush=True)
            try:
                c.toggle_detach()
                app.update()
                time.sleep(0.45)
                detached = getattr(c, '_floating_win', None) is not None
                print(f" - detached: {detached}", flush=True)
            except Exception as e:
                print(f" - detach error: {e}", flush=True)
                traceback.print_exc()
            try:
                c.toggle_detach()
                app.update()
                time.sleep(0.25)
                detached = getattr(c, '_floating_win', None) is not None
                print(f" - after dock detached: {detached}", flush=True)
            except Exception as e:
                print(f" - dock error: {e}", flush=True)
                traceback.print_exc()
        print("Done tests, destroying app.", flush=True)
        app.destroy()
    except Exception as e:
        print("Exception during test:", e, flush=True)
        traceback.print_exc()
        try:
            if app:
                app.destroy()
        except Exception:
            pass


if __name__ == '__main__':
    main()

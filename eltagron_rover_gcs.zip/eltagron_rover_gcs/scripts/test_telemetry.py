#!/usr/bin/env python3
import os
import sys
import time
import traceback

# Ensure project root is on sys.path when running from scripts/
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from rover_gcs.app import RoverGCSApp


def main():
    app = None
    try:
        app = RoverGCSApp()
        app.update()
        print("map_widget present:", bool(getattr(app, "map_widget", None)))
        print("fallback_map present:", bool(getattr(app, "fallback_map", None)))

        frames = [
            "GPS:39.7469865,30.4740988,0.5",
            "IMU:10.0,0.01,0.02,-0.01",
            "GPS:39.7470865,30.4741988,1.2",
            "IMU:11.0,0.02,0.01,0.00",
            "GPS:39.7471865,30.4742988,2.7",
        ]

        for line in frames:
            print("PUSH ->", line)
            app.serial.rx_queue.put(line)
            # process immediately
            app.ui_loop()
            app.update()
            time.sleep(0.12)
            print(" Telemetry state:", f"lat={app.telemetry.lat}", f"lon={app.telemetry.lon}", f"speed={app.telemetry.speed_kmph}", f"yaw={app.telemetry.yaw_deg}")
            if hasattr(app, "row_lat"):
                try:
                    print(" UI rows:", app.row_lat.get(), app.row_lon.get(), app.row_speed.get(), app.row_yaw.get())
                except Exception:
                    pass
            if getattr(app, "map_widget", None):
                print(" map_marker:", getattr(app, "map_marker", None) is not None)
            else:
                print(" path_points len:", len(app.path_points))

        print("TEST COMPLETE")
    except Exception as e:
        print("EXCEPTION:", e)
        traceback.print_exc()
    finally:
        if app:
            try:
                app.destroy()
            except Exception:
                pass


if __name__ == '__main__':
    main()

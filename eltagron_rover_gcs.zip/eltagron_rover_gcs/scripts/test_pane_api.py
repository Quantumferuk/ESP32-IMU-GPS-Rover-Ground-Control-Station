#!/usr/bin/env python3
import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from rover_gcs.app import RoverGCSApp

app = RoverGCSApp()
app.update()
print('main_pane:', bool(getattr(app, 'main_pane', None)))
print('top_pane:', bool(getattr(app, 'top_pane', None)))
print('bottom_pane:', bool(getattr(app, 'bottom_pane', None)))
print('set_top sash result:', app.set_top_sash(0, 220))
app.destroy()

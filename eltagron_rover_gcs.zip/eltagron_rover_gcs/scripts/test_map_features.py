#!/usr/bin/env python3
"""Quick automated test for map destination and tile switching.
"""
import os
import sys
import time
import traceback

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from rover_gcs.app import RoverGCSApp


def main():
    app = None
    try:
        app = RoverGCSApp()
        app.update(); time.sleep(0.05)
        has_map = getattr(app, 'map_widget', None) is not None
        print('map_widget:', bool(has_map))
        if has_map:
            # set a destination
            lat, lon = 39.7475, 30.4745
            try:
                app.set_map_destination(lat, lon, text='DEST_TEST')
                app.update(); time.sleep(0.05)
                print('dest_marker:', getattr(app, 'dest_marker', None) is not None)
                print('dest_path:', getattr(app, 'dest_path', None) is not None)
            except Exception as exc:
                print('set_map_destination failed:', exc)

            # try tile servers
            tiles = ['Carto Dark', 'Carto Light', 'OpenStreetMap', 'Stamen Toner', 'Esri Satellite']
            for t in tiles:
                try:
                    app._set_tile_server(t)
                    app.update(); time.sleep(0.05)
                    print('tile_applied:', t)
                except Exception as exc:
                    print('tile_failed:', t, exc)

            # simulate rover move to update path
            try:
                app.telemetry.lat = 39.7469
                app.telemetry.lon = 30.4741
                app.path_points = [(app.telemetry.lat, app.telemetry.lon)]
                app.update_map_position(app.telemetry.lat, app.telemetry.lon)
                app.update(); time.sleep(0.05)
                print('map_marker:', getattr(app, 'map_marker', None) is not None)
            except Exception as exc:
                print('update_map_position failed:', exc)
        else:
            print('no_map_widget, fallback_map exists:', getattr(app, 'fallback_map', None) is not None)

    except Exception as exc:
        print('EXC', exc)
        traceback.print_exc()
    finally:
        try:
            if app:
                app.destroy()
        except Exception:
            pass


if __name__ == '__main__':
    main()

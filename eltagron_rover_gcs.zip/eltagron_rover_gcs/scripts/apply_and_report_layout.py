#!/usr/bin/env python3
import os
import sys
import time
import traceback

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from rover_gcs.app import RoverGCSApp


def print_pane_info(pane, name):
    if not pane:
        print(f"{name}: None")
        return
    try:
        panes = pane.panes()
    except Exception:
        panes = pane.winfo_children() or []
    n_panes = len(panes)
    n_sashes = max(0, n_panes - 1)
    print(f"{name}: panes={n_panes}, sashes={n_sashes}")
    try:
        children = pane.winfo_children()
        sizes = [(c.winfo_width(), c.winfo_height()) for c in children]
        print(f"  child sizes: {sizes}")
    except Exception:
        print("  child sizes: (error)")
    for i in range(n_sashes):
        pos = None
        try:
            pos = pane.sashpos(i)
        except Exception:
            try:
                pos = int(pane.tk.call(pane._w, 'sashpos', i))
            except Exception:
                pos = None
        print(f"  sash {i} pos: {pos}")


def main():
    app = None
    try:
        app = RoverGCSApp()
        app.update(); time.sleep(0.05)
        print("-- BEFORE --")
        print_pane_info(getattr(app, 'main_pane', None), 'main_pane')
        print_pane_info(getattr(app, 'top_pane', None), 'top_pane')
        print_pane_info(getattr(app, 'bottom_pane', None), 'bottom_pane')

        ratio_layout = {
            'main_pane': [0.58, 0.28, 0.14],
            'top_pane': [0.62, 0.25, 0.13],
            'bottom_pane': [0.22, 0.28, 0.50],
        }

        print('\n-- APPLYING restore_ratio_layout --')
        results = app.restore_ratio_layout(ratio_layout, attempts=8, delay=0.05)
        for name, vals in results.items():
            print(f" restore result {name}: {vals}")

        print('\n-- AFTER --')
        print_pane_info(getattr(app, 'main_pane', None), 'main_pane')
        print_pane_info(getattr(app, 'top_pane', None), 'top_pane')
        print_pane_info(getattr(app, 'bottom_pane', None), 'bottom_pane')

    except Exception as exc:
        print('EXCEPTION', exc)
        traceback.print_exc()
    finally:
        try:
            if app:
                app.destroy()
        except Exception:
            pass


if __name__ == '__main__':
    main()

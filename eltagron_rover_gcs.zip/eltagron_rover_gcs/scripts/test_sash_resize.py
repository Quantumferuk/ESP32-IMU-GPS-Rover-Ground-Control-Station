#!/usr/bin/env python3
import os
import sys
import time
import traceback

# Ensure project root is on sys.path when running from scripts/
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import tkinter as tk
from rover_gcs.app import RoverGCSApp


def find_paneds(w):
    res = []
    try:
        for ch in w.winfo_children():
            try:
                if isinstance(ch, tk.PanedWindow):
                    res.append(ch)
            except Exception:
                pass
            try:
                res.extend(find_paneds(ch))
            except Exception:
                pass
    except Exception:
        pass
    return res


def main():
    app = None
    try:
        app = RoverGCSApp()
        app.update()
        frame = app.page_frames.get("Dashboard")
        if not frame:
            print("Dashboard frame not found")
            app.destroy()
            return

        pws = find_paneds(frame)
        print(f"Found {len(pws)} PanedWindow(s)")

        for i, pw in enumerate(pws):
            print("--- PanedWindow", i, "---")
            app.update(); app.update_idletasks()
            children = pw.winfo_children()
            print(" children types:", [type(c).__name__ for c in children])
            sizes_init = [(c.winfo_width(), c.winfo_height()) for c in children]
            print(" initial sizes:", sizes_init)

            # determine number of sashes (panes-1)
            try:
                panes = pw.panes()
            except Exception:
                panes = tuple(str(c) for c in children)
            n_sashes = max(0, len(panes) - 1)
            print(" n_sashes:", n_sashes)

            for idx in range(n_sashes):
                try:
                    print(f" moving sash {idx}")
                    try:
                        cur = pw.sashpos(idx)
                        print("  current sashpos:", cur)
                    except Exception:
                        cur = None
                    w = pw.winfo_width(); h = pw.winfo_height()
                    # heuristic new position: shift towards right/bottom
                    if w and pw.cget('orient') == 'horizontal':
                        new = max(30, min(w - 30, int(w * (0.5 + 0.1 * idx))))
                    elif h and pw.cget('orient') == 'vertical':
                        new = max(30, min(h - 30, int(h * (0.5 + 0.1 * idx))))
                    else:
                        new = (cur or 200) + 80

                    moved = False
                    # try sashpos setter
                    try:
                        pw.sashpos(idx, new)
                        moved = True
                        print("  set via sashpos to", new)
                    except TypeError:
                        try:
                            pw.sash_place(idx, new, h // 2)
                            moved = True
                            print("  set via sash_place to", new)
                        except Exception:
                            pass
                    except Exception:
                        pass

                    if not moved:
                        try:
                            # fallback: set pane size via config on child
                            child = children[idx]
                            child.config(width=new)
                            print("  set child.width via config", new)
                        except Exception as e:
                            print("  fallback failed:", e)

                    app.update(); app.update_idletasks(); time.sleep(0.12)
                    sizes_after = [(c.winfo_width(), c.winfo_height()) for c in children]
                    print("  sizes after:", sizes_after)

                except Exception as e:
                    print("  error moving sash:", e)
                    traceback.print_exc()

        print("SASH TEST COMPLETE")
    except Exception as e:
        print("EXCEPTION:", e)
        traceback.print_exc()
    finally:
        if app:
            try:
                app.destroy()
            except Exception:
                pass


if __name__ == '__main__':
    main()
